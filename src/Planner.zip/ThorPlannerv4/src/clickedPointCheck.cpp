#include "ros/ros.h"
#include "std_msgs/String.h"
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_broadcaster.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

#include "ThorPlanner/Astarv3.h"
#include "ThorPlanner/grassfire.h"
#include "ThorPlanner/obsCostMap.h"
#include "ThorPlanner/TrajFromNodes.h"
#include "ThorPlanner/kdtree.h"
#include "ThorPlanner/Bezier.h"
#include "ThorPlanner/TF.h"

ThorPlanner::TF tfTh;
ros::Publisher pubClick;

void callbackClicked(const geometry_msgs::PointStamped::ConstPtr& msg){
	Node n(msg->point.x, msg->point.y, 0);
	Node ns;
	tfTh.mapTONode(n,ns);

	geometry_msgs::PointStamped ptPub;
	ptPub.header = msg->header;
	ptPub.point.x = ns.x;
	ptPub.point.y = ns.y;
	ptPub.point.z = ns.z;

	std::cout<<"Msg : "<<msg->point.x<<", "<<msg->point.y<<std::endl;
	std::cout<<"Node : "<<ns.x<<", "<<ns.y<<std::endl;
	std::cout<<"------------------------------------"<<std::endl;

	pubClick.publish(ptPub);
}


int main(int argc, char** argv){
	ros::init(argc, argv, "ClickePointCheckNode");
	ros::NodeHandle nh;

	ros::Subscriber subClick = nh.subscribe("/clicked_point", 1, callbackClicked);
	pubClick = nh.advertise<geometry_msgs::PointStamped>("/clicked_point_reflex", 1);

	ros::Rate loop_rate(10);
	while(ros::ok()){
		ros::spinOnce();

		loop_rate.sleep();
	}
}