#include "ros/ros.h"
#include "std_msgs/String.h"
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_broadcaster.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

#include "ThorPlanner/Astarv3.h"


std::vector<Node> path;
nav_msgs::Path pathNav;
cv::Mat map;
bool inCallback = false;
float originX = 0.7;
float originY = 0.35;
float originO = 0.12;
float mapRes = 0.05;

ros::Subscriber localPathSub;
ros::Publisher pubCurr;

Node cvTOmap(Node pt){
	Node ptShift;
	Node ptMapBotOrigin(pt.x*mapRes, (map.rows - pt.y)*mapRes,0);
	ptShift.x = (ptMapBotOrigin.x - originX)*cos(originO) + (ptMapBotOrigin.y - originY)*sin(originO);
	ptShift.y = -(ptMapBotOrigin.x - originX)*sin(originO) + (ptMapBotOrigin.y - originY)*cos(originO);
	ptShift.orien = pt.orien - originO;

	return ptShift;
}

Node mapTOcv(Node pt){
	Node ptShift;
	Node ptMapBotOrigin;
	ptMapBotOrigin.x = pt.x*cos(-originO) + pt.y*sin(-originO) + originX;
	ptMapBotOrigin.y = -pt.x*sin(-originO) + pt.y*cos(-originO) + originY;

	ptShift.x =	ptMapBotOrigin.x/mapRes;
	ptShift.y = map.rows - ptMapBotOrigin.y/mapRes;
	ptShift.orien = pt.orien + originO;

	return ptShift;
}

void callbackLocalPath(const nav_msgs::Path::ConstPtr& msg){
	pathNav = *msg;
	path.clear();
	for(int i = 0;i < msg->poses.size();i++){
		geometry_msgs::PoseStamped ptPose = msg->poses[i];
		tf::Pose tfPose;
		tf::poseMsgToTF(ptPose.pose,tfPose);
		double yaw = tf::getYaw(tfPose.getRotation());

		Node ptNode(ptPose.pose.position.x, ptPose.pose.position.y, yaw);
		path.push_back(mapTOcv(ptNode));
	}		

}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "LocalPathSub");
	ros::NodeHandle nh;

	map = cv::imread(MapData::MapAddress,0);
	pubCurr = nh.advertise<geometry_msgs::PoseStamped>("/Localization", 10);

	while(ros::ok()){
		cv::Mat imgDisp = map.clone();
		localPathSub = nh.subscribe("/ThorPlanner/LocalPathForward", 1, callbackLocalPath);
		ros::spinOnce();

		if(path.size() > 0){
			for(Node pt : path)
				cv::circle(imgDisp, cv::Point(pt.x,pt.y),3,155,-1);

			cv::imshow("image",imgDisp);
			cv::waitKey(1);
		}

		if(pathNav.poses.size() > 5)
			pubCurr.publish(pathNav.poses[5]);
	}


	return 0;
}