#include <iostream>
#include "purepursuit.h"

#include "ThorPlanner/Astarv3.h"
#include "ThorPlanner/grassfire.h"
#include "ThorPlanner/obsCostMap.h"
#include "ThorPlanner/optimizer.h"


int mainPurePursuit(){
	Node start(100,80,0);
	start.velocity = 5;
	start.delta = 0;
	std::vector<Node> path;
	cv::Mat img = cv::Mat::zeros(500,500,CV_8UC1);

	for(int i = 100;i < 400;i++)
		path.push_back(Node(i,100,0));

	for(int i = 100;i < 400;i++)
		path.push_back(Node(400,i,PI/2));

	for(int i = 400;i < 410;i++)
		path.push_back(Node(i,400,0));

	std::vector<Node> path_pursuit;
	PurePursuit pp(start,path);	
	pp.genPursuit(path_pursuit);

	dispPath(img,path);
	dispPath(img,path_pursuit);
	cv::imshow("image",img);
	cv::waitKey(0);
}


int mainAstar(){
	Node start(90,200,0);
	Node goal(400,420,0);
	cv::Mat img = cv::imread("CostMap.png",0);

	Eigen::MatrixXd obstacles;
	Eigen::MatrixXf heuristicCost;
	std::vector<Node> path;

	Astar ast(img, heuristicCost);
	ast.genTrajectory(start,goal,path);

	cv::Mat imgDisp = img.clone();
	for(Node n : path)
		cv::circle(imgDisp,cv::Point(n.x,n.y),3,155,-1);

	cv::imshow("Dimage",imgDisp);
	cv::waitKey(0);
}

// float maxMat(Eigen::MatrixXf mat){
float maxMat(Eigen::MatrixXf& matCosts){
	float maxi = -100000000000000;

	for(int i = 0;i < matCosts.rows();i++){
		for(int j = 0;j < matCosts.cols();j++){
			if(matCosts(i,j) > maxi && matCosts(i,j) < 1000000000)
				maxi = matCosts(i,j);
		}
	}

	return maxi;
}

void dispCosts(Eigen::MatrixXf& matCosts){
	cv::Mat img = cv::Mat::zeros(matCosts.rows(),matCosts.cols(),CV_8UC1);
	float maxVal = maxMat(matCosts);

	for(int i = 0;i < matCosts.rows();i++){
		for(int j = 0;j < matCosts.cols();j++){
			if(matCosts(i,j) < 10000)
				img.at<uchar>(i,j) = matCosts(i,j)*255/maxVal;
		}
	}

	cv::imshow("image",img);
	cv::waitKey(0);

}

Node minInd(Eigen::MatrixXf pts){
	float minVal = std::numeric_limits<float>::infinity();
	Node ind;

	for(int i = 0;i < pts.cols();i++){
		for(int j = 0;j < pts.rows();j++){
			if(pts(j,i) < minVal){
				minVal = pts(j,i);
				ind.x = i;
				ind.y = j;
			}
		}
	}

	return ind;
}

void genPath(Node start, Eigen::MatrixXf mat_costs, std::vector<Node>& pts){
	Node curr = start;
	// cv::Mat imgCp = this->img.clone();

	pts.clear();
	pts.push_back(curr);
	Node prev(-1,-1,0);
	while(true){
		int x_low = curr.x - 1;
		if(x_low < 0)
			x_low = 0;

		int x_high = curr.x + 2;
		if(x_high > mat_costs.cols())
			x_high = mat_costs.cols();

		int y_low = curr.y - 1;
		if(y_low < 0)
			y_low = 0;

		int y_high = curr.y + 2;
		if(y_high > mat_costs.rows())
			y_high = mat_costs.rows();

		Eigen::MatrixXf mat_window = mat_costs.block(y_low, x_low, y_high - y_low, x_high - x_low);

		Node ind_lowNeigh = minInd(mat_window);
		ind_lowNeigh.makeNode(ind_lowNeigh.x + x_low, ind_lowNeigh.y + y_low, 0);

		curr = ind_lowNeigh;
		pts.push_back(curr);

		if(curr == prev){
			std::cout<<"Path Generated"<<std::endl;
			break;
		}

		prev = curr;
	}

}

void dispPath3(cv::Mat& img, std::vector<Node>& pts){
	uint cR = rand()%155 + 100;
	uint cG = rand()%155 + 100;
	uint cB = rand()%155 + 100;
	cv::Vec3b color(cB,cG,cR);

	for(int i = 0;i < pts.size();i++)
		img.at<cv::Vec3b>(pts[i].y, pts[i].x) = color;
}

void getFreePts(cv::Mat& img, std::vector<Node>& pts){
	pts.clear();
	for(int i = 0;i < img.rows;i++){
		for(int j = 0;j < img.cols;j++){
			if(img.at<uchar>(i,j) < 50)
				pts.push_back(Node(j,i,0));
		}
	}
}

void genPaths(Eigen::MatrixXf& matCosts, cv::Mat& imgMap){
	cv::Mat img = cv::Mat::zeros(matCosts.rows(),matCosts.cols(),CV_8UC3);
	std::vector<Node> pts;
	std::vector<Node> freePts;

	getFreePts(imgMap, freePts);

	for(int i = 0;i < imgMap.rows;i++){
		for(int j = 0;j < imgMap.cols;j++)
			img.at<cv::Vec3b>(i,j) = (imgMap.at<uchar>(i,j)/255)*cv::Vec3b(255,255,255);
	}

	std::cout<<freePts.size()<<std::endl;
	for(int i = 0;i < 10;i++){
		uint ind = rand() % freePts.size();

		// std::cout<<i<<std::endl;
		// std::cout<<freePts[i].x<<','<<freePts[i].y<<std::endl;
		genPath(freePts[ind], matCosts, pts);
		dispPath3(img,pts);

		cv::imshow("image",img);
		if(cv::waitKey(0) == 27)
			break;
	}


}

int mainGrassFire(){
	cv::Mat img = cv::imread("CostMap.png", 0);
	// std::pair<float,float> goal = std::make_pair(400,420);
	Node goal(400,420,0);

	Eigen::MatrixXf mat_costs = std::numeric_limits<float>::infinity()*Eigen::MatrixXf::Ones(img.rows,img.cols);

	GrassFire gf(img,goal);
	gf.genCosts(mat_costs);

	dispCosts(mat_costs);
}

int mainBrushFire(){
	cv::Mat img = cv::imread("CostMap.png",0);
	Eigen::MatrixXf matCosts = std::numeric_limits<float>::infinity()*Eigen::MatrixXf::Ones(img.rows,img.cols);

	ObsCostMap ocm(img);
	ocm.genCostMap(matCosts);

	dispCosts(matCosts);
	cv::imshow("image",img);
	cv::waitKey(0);
}

int mainBrushGrass(){
	cv::Mat img = cv::imread("CostMap.png",0);
	Node goal(400,420,0);
	Eigen::MatrixXf matCostsBrush = std::numeric_limits<float>::infinity()*Eigen::MatrixXf::Ones(img.rows,img.cols);
	Eigen::MatrixXf matCostsGrass = std::numeric_limits<float>::infinity()*Eigen::MatrixXf::Ones(img.rows,img.cols);
	Eigen::MatrixXf matCosts;

	GrassFire gf(img, goal);
	gf.genCosts(matCostsGrass);

	ObsCostMap ocm(img);
	ocm.genCostMap(matCostsBrush);

	float wBrush = 100;
	float wGrass = 1;

	matCosts = wBrush*matCostsBrush + wGrass*matCostsGrass;


	dispCosts(matCosts);
	genPaths(matCosts, img);
}

int mainAstarBrushGrass(){
	Node start(230,85,0);
	Node goal(640,680,PI/2);
	// Node goal(325,250,PI);
	start.velocity = 2;
	start.delta = 0;

	cv::Mat imgO = cv::imread(MapData::MapAddress, 0);
	cv::Mat img = imgO.clone();

	// cv::dilate(imgO.clone(), img, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(5, 5)));

	Eigen::MatrixXf matCostsBrush = std::numeric_limits<float>::infinity()*Eigen::MatrixXf::Ones(img.rows,img.cols);
	Eigen::MatrixXf matCostsGrass = std::numeric_limits<float>::infinity()*Eigen::MatrixXf::Ones(img.rows,img.cols);
	Eigen::MatrixXf matCosts;

	GrassFire gf(img, goal);
	gf.genCosts(matCostsGrass);
	std::cout<<"Grassfire Generated"<<std::endl;
	std::cout<<"------------------"<<std::endl;
	ObsCostMap ocm(img);
	ocm.genCostMap(matCostsBrush);
	std::cout<<"Brushfire Generated"<<std::endl;
	std::cout<<"------------------"<<std::endl;

	float wBrush = TuningParams::HeuristicCostsBrushFireFactor;
	float wGrass = TuningParams::HeuristicCostsGrassFireFactor;
	matCosts = wBrush*matCostsBrush + wGrass*matCostsGrass;

//astar
	Eigen::MatrixXd obstacles;
	std::vector<Node> path;
	std::vector<Node> path_pursuit;
	Astar ast(img, matCosts);

	clock_t t1, t2;
	t1 = clock();
	ast.genTrajectory(start, goal, path);
	t2 = clock();

	std::cout<<"Time : "<<float(t2-t1)/CLOCKS_PER_SEC<<std::endl;
	std::cout<<"Shortest Cost : "<<path[path.size()-1].g<<std::endl;
	std::cout<<"Astar Generated"<<std::endl;
	std::cout<<"------------------"<<std::endl;

	// std::vector<Node> pathMod;
	// for(int i = 0;i < path.size();i++)
	// 	pathMod.push_back(Node(path[i].x/MapData::MapRes,path[i].y/MapData::MapRes,path[i].orien));

//purepurusit

	// Node stp(start.x*MapData::MapRes, start.y*MapData::MapRes,start.orien);
	// stp.delta = start.delta;
	// stp.velocity = 2*MapData::MapRes;
	// PurePursuit pp(stp,path);	
	// pp.genPursuit(path_pursuit);
	// std::cout<<"Pursuit Generated"<<std::endl;
	// std::cout<<"------------------"<<std::endl;

//simulationzz
	cv::Mat img1 = imgO.clone();
	ast.CollisionSimulate(img1, path, 95 ,0);

//optimization
	// for(int i = 0;i < path.size();i++){
	// 	path[i].x /= MapData::MapRes;
	// 	path[i].y /= MapData::MapRes;
	// }
	// std::vector<Node> pathOpt;
	// Optimization opt(matCosts, img, ocm);
	// opt.genOptima(path, pathOpt);

	// pathOpt[0].orien = start.orien;
	// for(int i = 1;i < pathOpt.size();i++)
	// 	pathOpt[i].orien = atan2(pathOpt[i].y - pathOpt[i-1].y, pathOpt[i].x - pathOpt[i-1].x);

	// cv::Mat img2 = img.clone();
	// ast.CollisionSimulate(img2, pathOpt, 155 , 0);

}



// --------------------------------- IMPORTANT ---------------------------------
// astar actions and collision detection code was not generalised, change it later. Done
// collision detection function has to be modified Done
// giving more weight to different deltas
// control params
// dilating the map
// increasing the dimensions of the vehicle
// optimize the astar path for the points which are in some threshold distance from obstacles. Leave the remaining.
// you can increase the vehicle dimensions instead of dilation for keeping the vehicle away from obstacles.
// tune g value for more refined path.
// go through the entire package and trim or do necessary changes.
// look into the hash function and dictionary for generalization. Done
// try to add the final required orientation at goal or atleast the goal is lying in the required field of view from nodeCurr.
// try adding euclidean and brushfire and see the results, tune the values.

int main(){
	// mainPurePursuit();
	// mainAstar();
	// mainGrassFire();
	// mainBrushFire();
	// mainBrushGrass();
	mainAstarBrushGrass(); //add the resolution parameter and the collision detection for each actions instead of checking after the action.
}
