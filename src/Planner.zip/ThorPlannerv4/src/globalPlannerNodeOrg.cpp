#include "ros/ros.h"
#include "std_msgs/String.h"
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_broadcaster.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

#include "ThorPlanner/Astarv3.h"
#include "ThorPlanner/grassfire.h"
#include "ThorPlanner/obsCostMap.h"
#include "ThorPlanner/TrajFromNodes.h"
#include "ThorPlanner/kdtree.h"
#include "ThorPlanner/Bezier.h"



float originX = 0.7;
float originY = 0.35;
float originO = 0.12;
float mapRes = 0.05;

geometry_msgs::Pose currLoc, goalLoc;
Node currLocNode, goalLocNode;

ros::Publisher pubThorPlannerPath;
ros::Publisher pubThorPlannerPathForward;
ros::Publisher localPathPub;
ros::Subscriber subLocalization;
ros::Subscriber subGoalLocalization;

KDT::KDTree<KDT::MyPoint> kdt;
std::vector<KDT::MyPoint> kdt_pts;
std::vector<Node> global_pts;

void cvTOmap(cv::Mat& map, Node pt, Node& ptShift){
	Node ptMapBotOrigin(pt.x*mapRes, (map.rows - pt.y)*mapRes,0);
	ptShift.x = (ptMapBotOrigin.x - originX)*cos(originO) + (ptMapBotOrigin.y - originY)*sin(originO);
	ptShift.y = -(ptMapBotOrigin.x - originX)*sin(originO) + (ptMapBotOrigin.y - originY)*cos(originO);
	ptShift.orien = pt.orien - originO;
}

void mapTOcv(cv::Mat& map, Node pt, Node& ptShift){
	Node ptMapBotOrigin;
	ptMapBotOrigin.x = pt.x*cos(-originO) + pt.y*sin(-originO) + originX;
	ptMapBotOrigin.y = -pt.x*sin(-originO) + pt.y*cos(-originO) + originY;

	ptShift.x =	ptMapBotOrigin.x/mapRes;
	ptShift.y = map.rows - ptMapBotOrigin.y/mapRes;
	ptShift.orien = pt.orien + originO;
}

void shiftPtsCVtoMapMsg(cv::Mat& map, std::vector<Node>& pts, nav_msgs::Path& pathMsg){
	std::vector<geometry_msgs::PoseStamped> shiftPts;

	for(Node pt : pts){
		Node shiftPt;
		pt.x /= MapData::MapRes;
		pt.y /= MapData::MapRes;
		cvTOmap(map, pt, shiftPt);

		geometry_msgs::PoseStamped shiftPtMsg;
		shiftPtMsg.header.stamp = ros::Time::now();
		shiftPtMsg.header.frame_id = "map";

		shiftPtMsg.pose.position.x = shiftPt.x;
		shiftPtMsg.pose.position.y = shiftPt.y;

		tf2::Quaternion quat;
		quat.setRPY(0, 0, shiftPt.orien);
		shiftPtMsg.pose.orientation = tf2::toMsg(quat);

		shiftPts.push_back(shiftPtMsg);
	}

	pathMsg.header.frame_id = "map";
	pathMsg.header.stamp = ros::Time::now();
	pathMsg.poses = shiftPts;
}

void shiftPtsCVtoMap(cv::Mat& map, std::vector<Node>& pts, std::vector<Node>& shiftedPts){
	shiftedPts.clear();

	for(Node pt : pts){
		Node shiftPt;
		pt.x /= MapData::MapRes;
		pt.y /= MapData::MapRes;
		cvTOmap(map, pt, shiftPt);

		shiftedPts.push_back(shiftPt);
	}

}


void callBackLocalization(const nav_msgs::Odometry::ConstPtr& msg){
	currLoc = msg->pose.pose;

	tf::Pose tfPose;
	tf::poseMsgToTF(currLoc, tfPose);
	double currYaw = tf::getYaw(tfPose.getRotation());

	//facing some errors with the orientation, so enter manually in case of any errors
	// Node startPt(currLoc.position.x, currLoc.position.y ,0);
	currLocNode.x = currLoc.position.x;
	currLocNode.y = currLoc.position.y;
	currLocNode.orien = currYaw;

}

void callBackLocalizationO(const geometry_msgs::PoseStamped::ConstPtr& msg){
	currLoc = msg->pose;

	tf::Pose tfPose;
	tf::poseMsgToTF(currLoc, tfPose);
	double currYaw = tf::getYaw(tfPose.getRotation());

	//facing some errors with the orientation, so enter manually in case of any errors
	// Node startPt(currLoc.position.x, currLoc.position.y ,0);
	currLocNode.x = currLoc.position.x;
	currLocNode.y = currLoc.position.y;
	currLocNode.orien = currYaw;
}

void callBackGoalLocalization(const geometry_msgs::PoseStamped::ConstPtr& msg){
	goalLoc = msg->pose;

	tf::Pose tfPose;
	tf::poseMsgToTF(goalLoc, tfPose);
	double goalYaw = tf::getYaw(tfPose.getRotation());
	goalLocNode.x = goalLoc.position.x;
	goalLocNode.y = goalLoc.position.y; 
	goalLocNode.orien = goalYaw;
}


void buildKDT(){
	kdt_pts.clear();
	for(int i = 0;i < global_pts.size();i++)
		kdt_pts.push_back(KDT::MyPoint(global_pts[i].x, global_pts[i].y));

	kdt.build(kdt_pts);
}

int indSearch(geometry_msgs::Pose& pt){
	return kdt.nnSearch(KDT::MyPoint(pt.position.x, pt.position.y));
}

void genLocalPath(geometry_msgs::Pose& pt, nav_msgs::Path& localPath){
	std::vector<Node> localPathNode;
	uint ind = indSearch(pt);
	int localPath_nPts = TuningParams::nPtsLocalPath;

	localPath.header.frame_id = "map";
	localPath.header.stamp = ros::Time::now();

	for(int i = ind;i < std::min(ind + localPath_nPts, uint(global_pts.size()));i++)
		localPathNode.push_back(global_pts[i]);

	// std::vector<Node> localPathNodeSmoothed = localPathNode;
	std::vector<Node> localPathNodeSmoothed;
	BezierFit bezfit;
	bezfit.bezierCurveFit(localPathNode, localPathNodeSmoothed);

	for(int i = 0;i < localPathNodeSmoothed.size();i++){
		geometry_msgs::PoseStamped ptMsg;
		ptMsg.header.frame_id = "map";
		ptMsg.header.stamp = ros::Time::now();
		ptMsg.pose.position.x = localPathNodeSmoothed[i].x;
		ptMsg.pose.position.y = localPathNodeSmoothed[i].y;

		tf2::Quaternion quat;
		quat.setRPY(0, 0, localPathNodeSmoothed[i].orien);
		ptMsg.pose.orientation = tf2::toMsg(quat);

		localPath.poses.push_back(ptMsg);
	}
}

Node shiftFrontToBack(Node n){
	Node nShifted;
	nShifted = n;
	nShifted.x = nShifted.x - VehicleData::Length*cos(n.orien)/MapData::MapRes;
	nShifted.y = nShifted.y - VehicleData::Length*sin(n.orien)/MapData::MapRes;

	return nShifted;
}

Node shiftBackToFront(Node n){
	Node nShifted;
	nShifted = n;
	nShifted.x = nShifted.x + VehicleData::Length*cos(n.orien)/MapData::MapRes;
	nShifted.y = nShifted.y + VehicleData::Length*sin(n.orien)/MapData::MapRes;

	return nShifted;
}

int main(int argc, char **argv)
{
	currLocNode.x = -1000000000;
	goalLocNode.x = -1000000000;

	ros::init(argc, argv, "ThorGlobalPlanner");
	ros::NodeHandle nh;

	pubThorPlannerPath = nh.advertise<nav_msgs::Path>("/ThorPlanner/Path", 1);
	pubThorPlannerPathForward = nh.advertise<nav_msgs::Path>("/ThorPlanner/PathForward", 1);
	localPathPub = nh.advertise<nav_msgs::Path>("/ThorPlanner/LocalPathForward", 1);

	// subLocalization = nh.subscribe("/odometry/filtered", 10, callBackLocalization);
	subLocalization = nh.subscribe("/Localization", 10, callBackLocalizationO);

	subGoalLocalization = nh.subscribe("/GoalPose", 10, callBackGoalLocalization);
	// subGoalLocalization = nh.subscribe("/move_base_simple/goal", 1, callBackGoalLocalization);

// //map
	cv::Mat imgO = cv::imread(MapData::MapAddress, 0);
	cv::Mat img = imgO.clone();
	std::cout<<"-----------------"<<std::endl;
	if(!img.empty())
		std::cout<<"Map Loaded"<<std::endl;
	else{
		std::cout<<"Map not Loaded"<<std::endl;
		return 0;
	}
	std::cout<<"-----------------"<<std::endl;

	Astar ast(img);

	while(ros::ok()){
		ros::spinOnce();

		if(currLocNode.x > -1000000000 && goalLocNode.x > -1000000000){
			Node currLocNodeTemp;
			mapTOcv(img, currLocNode, currLocNodeTemp);
			currLocNodeTemp = shiftFrontToBack(currLocNodeTemp);
			currLocNodeTemp.x *= MapData::MapRes;
			currLocNodeTemp.y *= MapData::MapRes;
			bool retCollCurr = ast.CollisionCheckRobot(currLocNodeTemp);

			Node goalLocNodeTemp;
			mapTOcv(img, goalLocNode, goalLocNodeTemp);
			// goalLocNodeTemp = shiftFrontToBack(goalLocNodeTemp);
			goalLocNodeTemp.x *= MapData::MapRes;
			goalLocNodeTemp.y *= MapData::MapRes;
			bool retCollGoal = ast.CollisionCheckRobot(goalLocNodeTemp);

			if(retCollCurr){				
				std::cout<<"Current Location is in collision with Obstacles"<<std::endl;
				currLocNode.x = -1000000000;
			}
			if(retCollGoal){				
				std::cout<<"Goal Location is in collision with Obstacles"<<std::endl;
				goalLocNode.x = -1000000000;
			}
			std::cout<<"-----------------"<<std::endl;

			if(retCollCurr || retCollGoal)
				continue;

			break;

		}
	}

	std::cout<<"Feasible Start and Goal"<<std::endl;

	Node start, goal;
	mapTOcv(img, currLocNode, start);
	mapTOcv(img, goalLocNode, goal);
	start = shiftFrontToBack(start);
	start.velocity = 1;
	start.delta = 0;

	std::cout<<"------------------"<<std::endl;
	std::cout<<"Start : "<<start.x<<','<<start.y<<','<<start.orien<<std::endl;
	std::cout<<"Goal : "<<goal.x<<','<<goal.y<<','<<goal.orien<<std::endl;
	std::cout<<"------------------"<<std::endl;

	Eigen::MatrixXd obstacles;
	std::vector<Node> path;

	clock_t t1, t2;
	t1 = clock();
	path.clear();
	ast.initialize(start, goal);
	bool retAstar = ast.genTrajectory(path);
	t2 = clock();

	std::vector<Node> pathFrontWheel;
	TrajFromNodes tfn(path);
	tfn.genFrontCentredPoints(pathFrontWheel);

	shiftPtsCVtoMap(img, pathFrontWheel, global_pts);
	buildKDT();

	nav_msgs::Path pathMsg;
	nav_msgs::Path pathForwardMsg;
	if(retAstar){
		std::cout<<"Time : "<<float(t2-t1)/CLOCKS_PER_SEC<<std::endl;
		std::cout<<"Shortest Cost : "<<path[path.size()-1].g<<std::endl;
		std::cout<<"Astar Generated"<<std::endl;
		std::cout<<"Publishing Path"<<std::endl;
		std::cout<<"=============================="<<std::endl;

		shiftPtsCVtoMapMsg(img, pathFrontWheel, pathForwardMsg);
		shiftPtsCVtoMapMsg(img, path, pathMsg);
	}
	else{
		std::cout<<"Path Generation Failed"<<std::endl;
		std::cout<<"------------------"<<std::endl;
	}

	if(retAstar){
		while(ros::ok()){
			pubThorPlannerPath.publish(pathMsg);
			pubThorPlannerPathForward.publish(pathForwardMsg);
			// std::cout<<currLoc<<std::endl;

			nav_msgs::Path localNavPath;
			genLocalPath(currLoc, localNavPath);
			localPathPub.publish(localNavPath);
			ros::spinOnce();
		}
	}

	return 0;
}