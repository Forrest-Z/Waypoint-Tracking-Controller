#include <iostream>
#include "ros/ros.h"
#include "FluxMsgs/NodeArray.h"
#include "ThorPlanner/Data.h"
#include <fstream>



bool savedToFile = false;
void saveIntoFile(int ns, std::vector<Node>& pts){
	std::string fileName = "Path_" + std::to_string(ns) + ".txt";

    std::ofstream outFile(fileName);
    for(Node n : pts)
     	outFile << std::to_string(n.x)<< ' ' << std::to_string(n.y)<< ' ' << std::to_string(n.orien)<<"\n";	
}

void callbackPath(const FluxMsgs::NodeArray::ConstPtr& msg){

    if(!savedToFile){
        std::cout<<"Recieved Data"<<std::endl;
        std::vector<Node> pts;
        for(int i = 0;i < msg->path.size();i++){
            FluxMsgs::Node n = msg->path[i];
            pts.push_back(Node(n.x,n.y,n.orien));
        }

        saveIntoFile(1, pts);
        
        savedToFile = true;
    }
}



int main(int argc, char** argv){
    ros::init(argc,argv, "TopicToFile");
    ros::NodeHandle nh;

    ros::Subscriber sub = nh.subscribe("/ThorPlanner/GlobalPathNodeArray",1,callbackPath);
    while(ros::ok()){
        ros::spinOnce();

        if(savedToFile)
            break;
    }

}