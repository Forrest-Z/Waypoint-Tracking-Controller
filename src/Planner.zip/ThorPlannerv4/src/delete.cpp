#include <iostream>
#include <cmath>

#define PI 3.141592653589793238
#include "Data.h"

Node executeAction(float delta, float v, float t){
	float L = 1.45;

	float x, y, orien;
	if(delta != 0){		
		orien = v*tan(delta)*t/L;
		x = L*(sin(orien))/tan(delta);
		y = L*(1 - cos(orien))/tan(delta);
	}
	else{
		orien = 0;
		x = v*t;
		y = 0;
	}

	return Node(x,y,orien);
}


int main2(){

	cv::Mat img = cv::imread("CostMap.png",0);
	cv::Mat imgEr;
	cv::erode(img, imgEr, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(15, 15)));

	// cv::imshow("image",img);
	// cv::waitKey(0);

	int i = 0;
	while(true){
		cv::Mat imgErCl = imgEr.clone();
		imgErCl.at<uchar>(i,130) = 155;

		cv::imshow("image",imgErCl);
		uint key = cv::waitKey(1);
		std::cout<<i<<std::endl;
		if(key == 32)
			i++;
		if(key == 27)
			break;
	}

}

int main3(){
	cv::Mat img = cv::imread("Map.png",0);
	for(int i = 0;i < 220;i++){
		for(int j = 0;j < img.cols;j++)
			img.at<uchar>(i,j) = 255;
	}	

	for(int i = 430;i < img.rows;i++){
		for(int j = 0;j < img.cols;j++)
			img.at<uchar>(i,j) = 255;
	}	

	cv::imshow("image",img);
	cv::waitKey(0);
	cv::imwrite("MapMod.png",img);
}

void genBoundaryPts(std::vector<Node>& boundaryPts){
	std::vector<Node> endPts{Node(-0.253, 0.593,0), Node(1.742, 0.593, 0), Node(1.742, -0.593, 0), Node(-0.253, -0.593, 0), Node(-0.253, 0.593,0)};	//do not change the order.
	boundaryPts.push_back(endPts[0]);

	for(int i = 1;i < endPts.size();i++){
		int numPts = 6 + i%2;
		for(int alpha = 1;alpha <= numPts;alpha++){
			float x = (1.0 - alpha/float(numPts))*endPts[i-1].x + (alpha/float(numPts))*endPts[i].x; 
			float y = (1.0 - alpha/float(numPts))*endPts[i-1].y + (alpha/float(numPts))*endPts[i].y;
			boundaryPts.push_back(Node(x, y, 0));
		}
	}
}

void genEdge(Node& n1, Node& n2, std::vector<Node>& pts){
	float dist = Distance(n1, n2);
	int nPts = dist/0.1;	// generating points with 0.1 gap.

	for(int i = 0;i <= nPts;i++)
		pts.push_back(Node((1 - i/float(nPts))*n1.x + i*n2.x/float(nPts), (1 - i/float(nPts))*n1.y + i*n2.y/float(nPts), 0));
}

Node shiftFrame(Node& orig, Node& n){
	Node shiftNode;

	shiftNode.x = n.x*cos(-orig.orien) + n.y*sin(-orig.orien) - (-orig.x);
	shiftNode.y = -n.x*sin(-orig.orien) + n.y*cos(-orig.orien) - (-orig.y);
	shiftNode.orien = n.orien - orig.orien;
	shiftNode.orien = (inRo(shiftNode.orien*180/PI)%360)*PI/180;

	return shiftNode;
}


void genEdgePts(float delta, float velocity, float t, std::vector<Node>& pts){
	std::vector<Node> endPts{Node(-0.253, 0.593,0), Node(1.742, 0.593, 0), Node(1.742, -0.593, 0), Node(-0.253, -0.593, 0), Node(-0.253, 0.593,0)};	//do not change the order.
	std::vector<Node> pts0, pts1, pts2, pts3, pts4, pts5;

	uint pt0_ind, pt1_ind, pt2_ind, pt3_ind;
	pt0_ind = delta < 0 && velocity > 0 ? 0 : 3;
	pt1_ind = delta < 0 && velocity > 0 ? 1 : 2;
	pt2_ind = delta < 0 && velocity > 0 ? 2 : 1;
	pt3_ind = delta < 0 && velocity > 0 ? 3 : 0;

	pt0_ind = delta < 0 && velocity < 0 ? 2 : 1;
	pt1_ind = delta < 0 && velocity < 0 ? 3 : 0;
	pt2_ind = delta < 0 && velocity < 0 ? 0 : 3;
	pt3_ind = delta < 0 && velocity < 0 ? 1 : 2;

	genEdge(endPts[pt0_ind],endPts[pt1_ind],pts0);
	genEdge(endPts[pt3_ind],endPts[pt0_ind],pts5);

	Node pt, pt1, pt2, pt3;
	int nPts = std::fabs(velocity)*t/0.05;
	for(int i = 0;i <= nPts;i++){
		pt = executeAction(delta, velocity, t*i/float(nPts));
		pt1 = shiftFrame(pt, endPts[pt1_ind]);
		pt3 = shiftFrame(pt, endPts[pt3_ind]);

		pts1.push_back(pt1);
		pts4.push_back(pt3);
	}
	pt2 = shiftFrame(pt, endPts[pt2_ind]);

	genEdge(pt1, pt2, pts2);
	genEdge(pt2, pt3, pts3);

	std::reverse(pts4.begin(), pts4.end());
	pts.insert(pts.end(), pts0.begin(), pts0.end());
	pts.insert(pts.end(), pts1.begin(), pts1.end());
	pts.insert(pts.end(), pts2.begin(), pts2.end());
	pts.insert(pts.end(), pts3.begin(), pts3.end());
	pts.insert(pts.end(), pts4.begin(), pts4.end());
	pts.insert(pts.end(), pts5.begin(), pts5.end());
}

void getBoundPts(Node n, std::vector<Node>& shiftBoundPts){
	std::vector<Node> boundaryPts;
	genBoundaryPts(boundaryPts);

	for(int i = 0;i < boundaryPts.size();i++){
		Node shiftBoundPt = shiftFrame(n, boundaryPts[i]);
		shiftBoundPts.push_back(shiftBoundPt);
	}
}

int main23(){
	cv::Mat img = cv::imread("MapMod.png",0);
	cv::Mat imgC = img.clone();

	std::vector<Node> pts;
	Node ptRobot(5.8225,7.266,0.7505);
	genEdgePts(PI/3, -1, 0.2, pts);
	for(int i = 0;i < pts.size();i++){
		Node shiftNode = shiftFrame(ptRobot, pts[i]);
		cv::circle(imgC, cv::Point(shiftNode.x/0.0275, shiftNode.y/0.0275),2,255,-1);

		std::cout<<uint(img.at<uchar>(shiftNode.y/0.0275,shiftNode.x/0.0275))<<std::endl;
		if(img.at<uchar>(shiftNode.y/0.0275,shiftNode.x/0.0275) > 50)
			std::cout<<"Collision"<<std::endl;

		cv::imshow("image",imgC);
		cv::waitKey(100);
	}

	cv::waitKey(0);

}

int dagadmain(){
	float delta = PI/6;
	float velocity = -1;
	float t = 2;
	std::vector<Node> ptsN;
	std::vector<cv::Point> pts;
	for(int i = 0;i <= 100;i++)
		getBoundPts(executeAction(delta, velocity, i*t/100), ptsN);

	std::cout<<ptsN.size()<<std::endl;

	for(int i = 0;i < ptsN.size();i++)
		pts.push_back(cv::Point(250 + ptsN[i].x/0.0275, 250 + ptsN[i].y/0.0275));

	std::vector<cv::Point> ptsHull;
	cv::convexHull(pts, ptsHull);

	cv::Mat img = cv::Mat::zeros(500,500,CV_8UC1);
	std::cout<<ptsHull.size()<<std::endl;

	for(int i = 1;i < pts.size();i++)
		cv::circle(img,pts[i],1,155,-1);

	cv::imshow("image",img);
	cv::waitKey(0);

	std::vector<Node> ptsd;
	genEdgePts(delta, velocity, t, ptsd);
	std::cout<<"Size : "<<ptsd.size()<<std::endl;
	for(int i = 0;i < ptsd.size();i++){
		cv::circle(img, cv::Point(ptsd[i].x/0.0275 + 250, ptsd[i].y/0.0275 + 250),2,255,-1);
		cv::imshow("image",img);
		cv::waitKey(100);
	}

	cv::waitKey(0);

}

bool isIn(std::vector<uint>& pts, uint val){
	for(uint v : pts){
		if(v == val)
			return true;
	}

	return false;
}
	
int main(){
	cv::Mat img = cv::imread("TestMap4.png");


	// for(int i = 0;i < img.cols;i++){
	// 	for(int j =0;j < img.rows;j++)
	// 		std::cout<<uint(img.at<uchar>(i,j))<<std::endl;
	// }

	// for(int i = 0;i < img.cols;i++){
	// 	for(int j = 0;j < img.rows;j++){
	// 		if(img.at<uchar>(i,j) < 125)
	// 			imgThresh.at<uchar>(i,j) = 0;
	// 		else
	// 			imgThresh.at<uchar>(i,j) = 255;

	// 	}
	// }

	// cv::imwrite("TestMap3.jpeg",imgThresh);

	std::vector<uint> pts;
	for(int i = 0;i < img.cols;i++){
		for(int j = 0;j < img.rows;j++){
			if(!isIn(pts, uint(img.at<uchar>(i,j)))){				
				pts.push_back(uint(img.at<uchar>(i,j)));
			}
		}
	}

	for(uint val : pts)
		std::cout<<val<<std::endl;

}