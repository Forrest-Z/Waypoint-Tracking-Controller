#include "ros/ros.h"
#include "std_msgs/String.h"
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <tf/transform_broadcaster.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

#include "ThorPlanner/Astarv3.h"
#include "ThorPlanner/grassfire.h"
#include "ThorPlanner/obsCostMap.h"


float originX = 0.7;
float originY = 0.35;
float originO = 0.12;
float mapRes = 0.05;

ros::Publisher pubGoal;
ros::Publisher pubCurr;
ros::Subscriber localPathSub;
nav_msgs::Path path;
geometry_msgs::PoseStamped curr;

void cvTOmap(cv::Mat& map, Node pt, Node& ptShift){
	Node ptMapBotOrigin(pt.x*mapRes, (map.rows - pt.y)*mapRes,0);
	ptShift.x = (ptMapBotOrigin.x - originX)*cos(originO) + (ptMapBotOrigin.y - originY)*sin(originO);
	ptShift.y = -(ptMapBotOrigin.x - originX)*sin(originO) + (ptMapBotOrigin.y - originY)*cos(originO);
	ptShift.orien = pt.orien - originO;
}

void mapTOcv(cv::Mat& map, Node pt, Node& ptShift){
	Node ptMapBotOrigin;
	ptMapBotOrigin.x = pt.x*cos(-originO) + pt.y*sin(-originO) + originX;
	ptMapBotOrigin.y = -pt.x*sin(-originO) + pt.y*cos(-originO) + originY;
	
	ptShift.x =	ptMapBotOrigin.x/mapRes;
	ptShift.y = map.rows - ptMapBotOrigin.y/mapRes;
	ptShift.orien = pt.orien + originO;
}

void callbackLocalPath(const nav_msgs::Path::ConstPtr& msg){
	path = *msg;
}

void callBackLocalizationInitialPose(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg){
	curr.pose = msg->pose.pose;
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "Fake");
	ros::NodeHandle nh;

	cv::Mat img = cv::imread(MapData::MapAddress,0);

	pubGoal = nh.advertise<geometry_msgs::PoseStamped>("/GoalPose", 10);
	pubCurr = nh.advertise<geometry_msgs::PoseStamped>("/Localization", 10);
	ros::Subscriber subCurr = nh.subscribe("/initialpose", 10, callBackLocalizationInitialPose);


	Node goalPt(50,140,PI-originO);
	Node goalMap;
	cvTOmap(img, goalPt, goalMap);
	tf2::Quaternion quatGoal;
	quatGoal.setRPY(0, 0, goalMap.orien);

	geometry_msgs::PoseStamped goal;
	goal.pose.position.x = goalMap.x;
	goal.pose.position.y = goalMap.y;
	goal.pose.position.z = 0;
	goal.pose.orientation = tf2::toMsg(quatGoal);


	Node startPt(50,140,PI/2);
	Node startMap;
	cvTOmap(img, startPt, startMap);
	tf2::Quaternion quatCurr;
	quatCurr.setRPY(0, 0, startMap.orien);

	curr.header.frame_id = "map";
	curr.pose.position.x = startMap.x;
	curr.pose.position.y = startMap.y;
	curr.pose.position.z = 0;
	curr.pose.orientation = tf2::toMsg(quatCurr);

	ros::Rate freqRate(10);

	localPathSub = nh.subscribe("/ThorPlanner/LocalPathForward", 1, callbackLocalPath);
	while(ros::ok()){
		if(path.poses.size() > 0)
			curr = path.poses[5];

		pubGoal.publish(goal);
		pubCurr.publish(curr);
		ros::spinOnce();
		freqRate.sleep();
	}

	return 0;
}