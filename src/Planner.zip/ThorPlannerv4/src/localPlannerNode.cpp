#include "ros/ros.h"
#include "std_msgs/String.h"
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/MapMetaData.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_broadcaster.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

#include "ThorPlanner/Astarv3.h"
#include "ThorPlanner/grassfire.h"
#include "ThorPlanner/obsCostMap.h"
#include "ThorPlanner/TrajFromNodes.h"
#include "ThorPlanner/kdtree.h"
#include "ThorPlanner/Bezier.h"
#include "ThorPlanner/TF.h"


Node currLoc(-12342245265,0,0);
std::vector<Node> globalPath;
bool pathRecieved = false;
ros::Subscriber subGlobalPath, subGlobalNodeArray, subLocalization, subMapData;
ros::Publisher pubLocalPath;
ThorPlanner::TF thTf;
bool mapDataRecieved = false;

void callbackGlobalPath(const nav_msgs::Path::ConstPtr& msg){
	if(!pathRecieved){
		for(int i = 0;i < msg->poses.size();i++){
			geometry_msgs::PoseStamped pt = msg->poses[i];
			tf::Pose tfPose;
			tf::poseMsgToTF(pt.pose, tfPose);
			double yaw = tf::getYaw(tfPose.getRotation());

			Node n(pt.pose.position.x, pt.pose.position.y, yaw);
			n.velocity = pt.header.seq == 0 ? -1 : 1;		// -1 for backware, 1 for forward
			globalPath.push_back(n);
			// std::cout<<globalPath.size()<<std::endl;
		}
		pathRecieved = true;
	}
}

void callBackMapData(const nav_msgs::MapMetaData::ConstPtr& msg){

	if(!mapDataRecieved){			
		MapData::MapRes = msg->resolution;
		MapData::OriginX = msg->origin.position.x;
		MapData::OriginY = msg->origin.position.y;

		tf::Pose tfPose;
		tf::poseMsgToTF(msg->origin, tfPose);
		MapData::OriginOrien = tf::getYaw(tfPose.getRotation());

		std::cout<<"Address : "<<MapData::MapAddress<<std::endl;
		std::cout<<"Origin X : "<<MapData::OriginX<<std::endl;
		std::cout<<"Origin Y : "<<MapData::OriginY<<std::endl;
		std::cout<<"Origin Orientation : "<<MapData::OriginOrien<<std::endl;
		std::cout<<"Resolution : "<<MapData::MapRes<<std::endl;

		MapData::Negate = 0;
		mapDataRecieved = true;
	}

}

void callbackGlobalPathNodeArray(const FluxMsgs::NodeArray::ConstPtr& msg){

	std::cout<<"ash-2"<<std::endl;
	std::cout<<"ash-1"<<std::endl;
	if(!pathRecieved){
		for(int i = 0;i < msg->path.size();i++){
			FluxMsgs::Node nMsg = msg->path[i];
			Node n = thTf.NodeMsgToNode(nMsg);
			globalPath.push_back(Node(0,0,0));
		}

		pathRecieved = true;
	}

}

void callbackGlobalPathNodeArray2(const FluxMsgs::NodeArray::ConstPtr& msg){
	if(!pathRecieved){
		for(int i = 0;i < msg->path.size();i++){
			FluxMsgs::Node nMsg = msg->path[i];
			Node n = thTf.NodeMsgToNode(nMsg);;
			globalPath.push_back(n);
		}

		pathRecieved = true;
	}

}

void callbackLocalization(const geometry_msgs::PoseStamped::ConstPtr& msg){
	tf::Pose tfPose;
	tf::poseMsgToTF(msg->pose, tfPose);
	double yaw = tf::getYaw(tfPose.getRotation());

	currLoc.x = msg->pose.position.x;
	currLoc.y = msg->pose.position.y;
	currLoc.orien = yaw;
}

void callbackLocalizationInitialPose(const geometry_msgs::PoseStamped::ConstPtr& msg){
	tf::Pose tfPose;
	tf::poseMsgToTF(msg->pose, tfPose);
	double yaw = tf::getYaw(tfPose.getRotation());

	currLoc.x = msg->pose.position.x;
	currLoc.y = msg->pose.position.y;
	currLoc.orien = yaw;
}

void callbackLocalizationInitialPose2(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg){
	tf::Pose tfPose;
	tf::poseMsgToTF(msg->pose.pose, tfPose);
	double yaw = tf::getYaw(tfPose.getRotation());

	currLoc.x = msg->pose.pose.position.x;
	currLoc.y = msg->pose.pose.position.y;
	currLoc.orien = yaw;
}

int genKDTree(int ind, KDT::KDTree<KDT::MyPoint>& kdt){
	std::vector<KDT::MyPoint> kdt_pts;
	kdt_pts.push_back(KDT::MyPoint(globalPath[ind].x, globalPath[ind].y));

	int ind_max;
	int sgn = globalPath[ind+1].velocity;		//direction of the nodes
	for(int i = ind+1;i < globalPath.size();i++){
		if(globalPath[i].velocity*sgn < 0)
			break;

		kdt_pts.push_back(KDT::MyPoint(globalPath[i].x, globalPath[i].y));
		ind_max = i;
	}

	kdt.build(kdt_pts);

	return ind_max;
}

void genLocalPath(int ind, int endInd, std::vector<Node>& path){
	path.clear();
	int sgn = globalPath[ind].velocity;

	// TrajFromNodes tfn(path);
	// tfn.genFrontCentredPoints(pathFrontWheel);

	for(int i = ind;i <= std::min(ind + TuningParams::nPtsLocalPath, endInd);i++){

		Node n = sgn > 0 ? thTf.shiftBackToFront2(globalPath[i]) : globalPath[i];
		// Node n = globalPath[i];
		if(i == endInd){
			// std::cout<<"ad"<<std::endl;
			n.velConstraint = 0;			// 0 for 0 vel, 1 for maxVel;
		}
		else
			n.velConstraint = 1;

		path.push_back(n);
	}

}

void publishPath(std::vector<Node>& path){

	nav_msgs::Path pathMsg;
	pathMsg.header.frame_id = "map";
	pathMsg.header.stamp = ros::Time::now();

	for(Node pt : path){
		geometry_msgs::PoseStamped ptMsg;
		ptMsg.header.frame_id = "map";
		ptMsg.header.stamp = ros::Time::now();
		ptMsg.header.seq = pt.velConstraint;
		// std::cout<<ptMsg.header.seq<<std::endl;
		ptMsg.pose.position.x = pt.x;
		ptMsg.pose.position.y = pt.y;

		tf2::Quaternion quat;
		quat.setRPY(0, 0, pt.orien);
		ptMsg.pose.orientation = tf2::toMsg(quat);

		pathMsg.poses.push_back(ptMsg);
	}

	pubLocalPath.publish(pathMsg);
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "ThorLocalPlanner");
	ros::NodeHandle nh;

	subGlobalPath = nh.subscribe("/ThorPlanner/GlobalPath", 1, callbackGlobalPath);
	subMapData = nh.subscribe("/map_metadata", 1, callBackMapData);

	if(!nh.getParam("free_th", MapData::FreeThresh))
		throw std::invalid_argument("ERROR, Global Planner Node, couldn't load free_th ROS Param");

	if(!nh.getParam("occu_th", MapData::OccupiedThresh))
		throw std::invalid_argument("ERROR, Global Planner Node, couldn't load occu_th ROS Param");

	if(!nh.getParam("map_address", MapData::MapAddress))
		throw std::invalid_argument("ERROR, Global Planner Node, couldn't load map_address ROS Param");

	while(ros::ok()){
		ros::spinOnce();
		if(mapDataRecieved)
			break;
	}
	thTf.initialise();

	subLocalization = nh.subscribe("/Localization", 10, callbackLocalization);
	// subLocalization = nh.subscribe("/ndt_pose", 10, callbackLocalizationInitialPose);
	// subLocalization = nh.subscribe("/pose_stamped", 10, callbackLocalizationInitialPose);
	subLocalization = nh.subscribe("/initialpose", 10, callbackLocalizationInitialPose2);
	subGlobalPath = nh.subscribe("/ThorPlanner/GlobalPathNodeArray", 1, callbackGlobalPathNodeArray2);
	// subGlobalPath = nh.subscribe("/ThorPlanner/GlobalPathNodeArrayForward", 1, callbackGlobalPathNodeArray2);

	pubLocalPath = nh.advertise<nav_msgs::Path>("/ThorPlanner/LocalPath", 1);

	while(ros::ok()){
		if(globalPath.size() != 0){
			std::cout<<"Received Global Path"<<std::endl;
			break;
		}
		else
			std::cout<<"Waiting for Global Path"<<std::endl;

		ros::spinOnce();
	}



	Node prevLoc(-127740,-121340,-131420);
	int ind = 0, prevEndInd = 0;
	while(ros::ok() && ind < globalPath.size()){
		ros::spinOnce();
		KDT::KDTree<KDT::MyPoint> kdt;
		int endInd = genKDTree(ind, kdt);

		while(ros::ok() && ind < endInd && currLoc.x != -12342245265){
			std::vector<Node> localPath, localPathSmoothed;
			ros::spinOnce();
			ind = kdt.nnSearch(KDT::MyPoint(currLoc.x, currLoc.y)) + prevEndInd;
			genLocalPath(ind, endInd, localPath);

			BezierFit bezfit;
			bezfit.bezierCurveFit(localPath, localPathSmoothed);
			prevLoc = currLoc;

			publishPath(localPathSmoothed);
			if(ind == endInd)
				prevEndInd = endInd;
		}

		kdt.clear();
		if(ind == globalPath.size()-1){
			std::cout<<"Reached Goal"<<std::endl;
			break;
		}
	}

	thTf.~TF();

	return 0;
}