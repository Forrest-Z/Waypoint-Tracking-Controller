#include <iostream>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

bool isIn(std::vector<uchar>& pts, uchar val){
	for(uchar v : pts){
		if(v == val)
			return true;
	}

	return false;
}

int main(){
	cv::Mat img = cv::imread("Map/WareHouseMap.png",0);
	cv::circle(img,cv::Point(230,370),3,155,-1);

	cv::imshow("image",img);
	cv::waitKey(0);
}


