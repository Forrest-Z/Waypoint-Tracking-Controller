#include <iostream>
#include "ThorPlanner/Astarv3.h"
#include "ThorPlanner/grassfire.h"
#include "ThorPlanner/obsCostMap.h"


void readFile(std::string fileName, std::vector<Node>& pts){
	pts.clear();
	std::ifstream infile(fileName);
	std::string line;
	while (std::getline(infile, line))
	{
	    std::istringstream iss(line);
	    float a, b, c;
	    if (!(iss >> a >> b >> c))
	    	break;

	    pts.push_back(Node(a,b,c));
	}

}

void genFileNames(std::vector<std::string>& fileNames){
	fileNames.clear();
	std::ifstream infile("Results/FileNames.txt");
	std::string line;
	while (std::getline(infile, line))
	{
	    std::istringstream iss(line);
	    std::string a;
	    if (!(iss >> a ))
	    	break;

	    fileNames.push_back(a);
	}

}

int main()
{
	std::vector<Node> testPts;
	std::vector<std::string> fileNames;
	genFileNames(fileNames);
	cv::Mat imgO = cv::imread(MapData::MapAddress, 0);
	Eigen::MatrixXf matCosts;
	std::vector<Node> path;

	for(std::string fileName : fileNames){
		std::cout<<fileName<<std::endl;
		path.clear();
		cv::Mat img = imgO.clone();
		readFile(fileName, path);

		Astar ast(img, matCosts);
		ast.CollisionSimulate(img, path, 95 ,0);			
	}
}