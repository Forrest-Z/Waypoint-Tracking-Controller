#include <iostream>
#include "purepursuit.h"

#include "ThorPlanner/Astarv3.h"
#include "ThorPlanner/grassfire.h"
#include "ThorPlanner/obsCostMap.h"


// Testing pts


void genTestPts(std::vector<Node>& pts){
	std::vector<Node> testPts{Node(135,370,PI/2), Node(135,370,-PI/2), Node(135,690,0), Node(135,690,-PI/2)
							 ,Node(290,85,0), Node(290,85,PI), Node(290,270,PI/2), Node(290,270,-PI/2), Node(290,500,PI/2), Node(290,500,-PI/2), Node(290, 690,0), Node(290, 690,PI)
							 ,Node(460,85,0), Node(460,85,PI), Node(460,270,PI/2), Node(460,270,-PI/2), Node(460,500,PI/2), Node(460,500,-PI/2), Node(460, 690,0), Node(460, 690,PI)
							 ,Node(625,85,0), Node(625,85,PI), Node(625,270,PI/2), Node(625,270,-PI/2), Node(625,500,PI/2), Node(625,500,-PI/2), Node(625, 690,0), Node(625, 690,PI)
							 ,Node(780,85,0), Node(780,85,PI), Node(795,270,PI/2), Node(795,270,-PI/2), Node(795,500,PI/2), Node(795,500,-PI/2), Node(780, 690,0), Node(780, 690,PI)};

	pts = testPts;
}

void saveIntoFile(Node goal, std::vector<Node>& pts){
	std::string fileName = "Results/Path_" + std::to_string(int(goal.x)) + "_" + std::to_string(int(goal.y)) + "_" + std::to_string(int((goal.orien + 2*PI)*180/PI)%360) + ".txt";

    std::ofstream outFile(fileName);
    for(Node n : pts)
     	outFile << std::to_string(n.x)<< ' ' << std::to_string(n.y)<< ' ' << std::to_string(n.orien)<<"\n";	
}

int main(){
	std::vector<Node> testPts;
	genTestPts(testPts);

	cv::Mat imgO = cv::imread(MapData::MapAddress, 0);
	Eigen::MatrixXf matCostsBrush = std::numeric_limits<float>::infinity()*Eigen::MatrixXf::Ones(imgO.rows,imgO.cols);
	Eigen::MatrixXf matCosts;
	ObsCostMap ocm(imgO);
	ocm.genCostMap(matCostsBrush);
	Eigen::MatrixXd obstacles;
	std::vector<Node> path;

	Node start(135,85,0);
	start.velocity = 2;
	start.delta = 0;
	std::vector<Node> failedPts;
	for(int i = 0;i < testPts.size();i++){
		Node goalPt = testPts[i];
		std::cout<<"Count : "<<i+1<<'/'<<testPts.size()<<std::endl;
		std::cout<<"Start : "<<start.x<<','<<start.y<<','<<start.orien<<std::endl;
		std::cout<<"Goal : "<<goalPt.x<<','<<goalPt.y<<','<<goalPt.orien<<std::endl;
		std::cout<<"------------------"<<std::endl;
		cv::Mat img = imgO.clone();

		Eigen::MatrixXf matCostsGrass = std::numeric_limits<float>::infinity()*Eigen::MatrixXf::Ones(img.rows,img.cols);
		GrassFire gf(img, goalPt);
		gf.genCosts(matCostsGrass);

		float wBrush = TuningParams::HeuristicCostsBrushFireFactor;
		float wGrass = TuningParams::HeuristicCostsGrassFireFactor;
		matCosts = wBrush*matCostsBrush + wGrass*matCostsGrass;

		clock_t t1, t2;
		t1 = clock();
		path.clear();
		Astar ast(img, matCosts);
		bool retAstar = ast.genTrajectory(start, goalPt, path);
		t2 = clock();

		if(retAstar){
			saveIntoFile(goalPt, path);
			std::cout<<"Time : "<<float(t2-t1)/CLOCKS_PER_SEC<<std::endl;
			std::cout<<"Shortest Cost : "<<path[path.size()-1].g<<std::endl;
			std::cout<<"Astar Generated"<<std::endl;
			std::cout<<"Saved to file"<<std::endl;
			std::cout<<"=============================="<<std::endl;
		}
		else{			
			std::cout<<"Path Generation Failed"<<std::endl;
			std::cout<<"------------------"<<std::endl;
			failedPts.push_back(goalPt);
		}

		// cv::Mat img1 = imgO.clone();
		// ast.CollisionSimulate(img1, path, 95 ,0);
	}

	if(failedPts.size() > 0)
		saveIntoFile(Node(-1,-1,0),failedPts);
}





