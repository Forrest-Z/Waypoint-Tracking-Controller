#include "ros/ros.h"
#include "std_msgs/String.h"
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/MapMetaData.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_broadcaster.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

#include "ThorPlanner/Astarv3.h"
#include "ThorPlanner/grassfire.h"
#include "ThorPlanner/obsCostMap.h"
#include "ThorPlanner/TrajFromNodes.h"
#include "ThorPlanner/kdtree.h"
#include "ThorPlanner/Bezier.h"
#include "ThorPlanner/TF.h"



geometry_msgs::Pose currLoc, goalLoc;
Node currLocNode, goalLocNode;

// ros::Publisher pubThorPlannerPathForward;
// ros::Publisher localPathPub;
ros::Publisher pubThorPlannerPath, pubThorPlannerPathNodeArray, pubThorPlannerPathNodeArrayForward, pubThorPlannerPathForward;
ros::Subscriber subLocalization;
ros::Subscriber subGoalLocalization;
ros::Subscriber subMapData;

KDT::KDTree<KDT::MyPoint> kdt;
std::vector<KDT::MyPoint> kdt_pts;
std::vector<Node> global_pts;
bool mapDataRecieved = false;


// for nav_msgs::Odometry
void callBackLocalization(const nav_msgs::Odometry::ConstPtr& msg){
	currLoc = msg->pose.pose;

	tf::Pose tfPose;
	tf::poseMsgToTF(currLoc, tfPose);
	double currYaw = tf::getYaw(tfPose.getRotation());

	//facing some errors with the orientation, so enter manually in case of any errors
	// Node startPt(currLoc.position.x, currLoc.position.y ,0);
	currLocNode.x = currLoc.position.x;
	currLocNode.y = currLoc.position.y;
	currLocNode.orien = currYaw;

}

// for geometry_msgs::PoseStamped (used for thor localization topic)
void callBackLocalizationO(const geometry_msgs::PoseStamped::ConstPtr& msg){
	currLoc = msg->pose;

	tf::Pose tfPose;
	tf::poseMsgToTF(currLoc, tfPose);
	double currYaw = tf::getYaw(tfPose.getRotation());

	//facing some errors with the orientation, so enter manually in case of any errors
	// Node startPt(currLoc.position.x, currLoc.position.y ,0);
	currLocNode.x = currLoc.position.x;
	currLocNode.y = currLoc.position.y;
	currLocNode.orien = currYaw;
}

// for geometry_msgs::PoseWithCovarianceStamped (used for /initialpose topic from rviz)
void callBackLocalizationInitialPose2(const geometry_msgs::PoseStamped::ConstPtr& msg){
	currLoc = msg->pose;

	tf::Pose tfPose;
	tf::poseMsgToTF(currLoc, tfPose);
	double currYaw = tf::getYaw(tfPose.getRotation());

	//facing some errors with the orientation, so enter manually in case of any errors
	// Node startPt(currLoc.position.x, currLoc.position.y ,0);
	currLocNode.x = currLoc.position.x;
	currLocNode.y = currLoc.position.y;
	currLocNode.orien = currYaw;
}

void callBackLocalizationInitialPose(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg){
	currLoc = msg->pose.pose;

	tf::Pose tfPose;
	tf::poseMsgToTF(currLoc, tfPose);
	double currYaw = tf::getYaw(tfPose.getRotation());

	//facing some errors with the orientation, so enter manually in case of any errors
	// Node startPt(currLoc.position.x, currLoc.position.y ,0);
	currLocNode.x = currLoc.position.x;
	currLocNode.y = currLoc.position.y;
	currLocNode.orien = currYaw;
}

void callBackGoalLocalization(const geometry_msgs::PoseStamped::ConstPtr& msg){
	goalLoc = msg->pose;

	tf::Pose tfPose;
	tf::poseMsgToTF(goalLoc, tfPose);
	double goalYaw = tf::getYaw(tfPose.getRotation());
	goalLocNode.x = goalLoc.position.x;
	goalLocNode.y = goalLoc.position.y;
	goalLocNode.orien = goalYaw;
}

void callBackMapData(const nav_msgs::MapMetaData::ConstPtr& msg){

	if(!mapDataRecieved){			
		MapData::MapRes = msg->resolution;
		MapData::OriginX = msg->origin.position.x;
		MapData::OriginY = msg->origin.position.y;

		tf::Pose tfPose;
		tf::poseMsgToTF(msg->origin, tfPose);
		MapData::OriginOrien = tf::getYaw(tfPose.getRotation());

		std::cout<<"Add : "<<MapData::MapAddress<<std::endl;
		std::cout<<"OriginX : "<<MapData::OriginX<<std::endl;
		std::cout<<"OriginY : "<<MapData::OriginY<<std::endl;
		std::cout<<"OriginOrien : "<<MapData::OriginOrien<<std::endl;
		std::cout<<"Res : "<<MapData::MapRes<<std::endl;

		MapData::Negate = 0;
		mapDataRecieved = true;
	}

}

void buildKDT(){
	kdt_pts.clear();
	for(int i = 0;i < global_pts.size();i++)
		kdt_pts.push_back(KDT::MyPoint(global_pts[i].x, global_pts[i].y));

	kdt.build(kdt_pts);
}

int indSearch(geometry_msgs::Pose& pt){
	return kdt.nnSearch(KDT::MyPoint(pt.position.x, pt.position.y));
}

void genLocalPath(geometry_msgs::Pose& pt, nav_msgs::Path& localPath){
	std::vector<Node> localPathNode;
	uint ind = indSearch(pt);
	int localPath_nPts = TuningParams::nPtsLocalPath;

	localPath.header.frame_id = "map";
	localPath.header.stamp = ros::Time::now();

	for(int i = ind;i < std::min(ind + localPath_nPts, uint(global_pts.size()));i++)
		localPathNode.push_back(global_pts[i]);

	// std::vector<Node> localPathNodeSmoothed = localPathNode;
	std::vector<Node> localPathNodeSmoothed;
	BezierFit bezfit;
	bezfit.bezierCurveFit(localPathNode, localPathNodeSmoothed);

	for(int i = 0;i < localPathNodeSmoothed.size();i++){
		geometry_msgs::PoseStamped ptMsg;
		ptMsg.header.frame_id = "map";
		ptMsg.header.stamp = ros::Time::now();
		ptMsg.pose.position.x = localPathNodeSmoothed[i].x;
		ptMsg.pose.position.y = localPathNodeSmoothed[i].y;

		tf2::Quaternion quat;
		quat.setRPY(0, 0, localPathNodeSmoothed[i].orien);
		ptMsg.pose.orientation = tf2::toMsg(quat);

		localPath.poses.push_back(ptMsg);
	}
}



int main(int argc, char **argv)
{
	currLocNode.x = -1000000000;
	goalLocNode.x = -1000000000;

	ros::init(argc, argv, "ThorGlobalPlannerv4");
	ros::NodeHandle nh;

	pubThorPlannerPath = nh.advertise<nav_msgs::Path>("/ThorPlanner/GlobalPath", 1);
	pubThorPlannerPathForward = nh.advertise<nav_msgs::Path>("/ThorPlanner/GlobalPathForward", 1);
	pubThorPlannerPathNodeArray = nh.advertise<FluxMsgs::NodeArray>("/ThorPlanner/GlobalPathNodeArray", 1);
	pubThorPlannerPathNodeArrayForward = nh.advertise<FluxMsgs::NodeArray>("/ThorPlanner/GlobalPathNodeArrayForward", 1);


	subLocalization = nh.subscribe("/initialpose", 10, callBackLocalizationInitialPose);
	// subLocalization = nh.subscribe("/pose_stamped", 10, callBackLocalizationInitialPose);
	// subLocalization = nh.subscribe("/ndt_pose", 10, callBackLocalizationInitialPose);
	subGoalLocalization = nh.subscribe("/move_base_simple/goal", 1, callBackGoalLocalization);
	subMapData = nh.subscribe("/map_metadata", 1, callBackMapData);

	if(!nh.getParam("free_th", MapData::FreeThresh))
		throw std::invalid_argument("ERROR, Global Planner Node, couldn't load free_th ROS Param");

	if(!nh.getParam("occu_th", MapData::OccupiedThresh))
		throw std::invalid_argument("ERROR, Global Planner Node, couldn't load occu_th ROS Param");

	if(!nh.getParam("map_address", MapData::MapAddress))
		throw std::invalid_argument("ERROR, Global Planner Node, couldn't load map_address ROS Param");

	while(ros::ok()){
		ros::spinOnce();
		if(mapDataRecieved)
			break;
	}

	ThorPlanner::TF thTf;
	thTf.initialise();
	cv::Mat imgO;
	thTf.getMap(imgO);
	cv::Mat img = imgO.clone();

	std::cout<<"-----------------"<<std::endl;
	if(!img.empty())
		std::cout<<"Map Loaded"<<std::endl;
	else{
		std::cout<<"Map not Loaded"<<std::endl;
		return 0;
	}
	std::cout<<"-----------------"<<std::endl;

	Astar ast(img);

	while(ros::ok()){
		ros::spinOnce();

		if(currLocNode.x > -1000000000 && goalLocNode.x > -1000000000){
			Node currLocNodeTemp;
			thTf.mapTONode(currLocNode, currLocNodeTemp);
			currLocNodeTemp = thTf.shiftFrontToBack(currLocNodeTemp);
			currLocNodeTemp.x *= MapData::MapRes;
			currLocNodeTemp.y *= MapData::MapRes;
			bool retCollCurr = ast.CollisionCheckRobot(currLocNodeTemp);

			Node goalLocNodeTemp;
			thTf.mapTONode(goalLocNode, goalLocNodeTemp);
			// goalLocNodeTemp = thTf.shiftFrontToBack(goalLocNodeTemp);
			goalLocNodeTemp.x *= MapData::MapRes;
			goalLocNodeTemp.y *= MapData::MapRes;
			bool retCollGoal = ast.CollisionCheckRobot(goalLocNodeTemp);

			std::cout<<"Curr Loc : "<<currLocNodeTemp.x<<','<<currLocNodeTemp.y<<std::endl;
			std::cout<<"Goal Loc : "<<goalLocNodeTemp.x<<','<<goalLocNodeTemp.y<<std::endl;
			std::cout<<"------------------------------------"<<std::endl;

			if(retCollCurr){
				std::cout<<"Current Location is in collision with Obstacles"<<std::endl;
				currLocNode.x = -1000000000;
			}
			if(retCollGoal){
				std::cout<<"Goal Location is in collision with Obstacles"<<std::endl;
				goalLocNode.x = -1000000000;
			}
			std::cout<<"-----------------"<<std::endl;

			if(retCollCurr || retCollGoal)
				continue;

			break;

		}
	}

	std::cout<<"Feasible Start and Goal"<<std::endl;

	Node start, goal;
	thTf.mapTONode(currLocNode, start);
	thTf.mapTONode(goalLocNode, goal);
	start = thTf.shiftFrontToBack(start);
	start.velocity = 1;
	start.delta = 0;

	std::cout<<"------------------"<<std::endl;
	std::cout<<"Start : "<<start.x<<','<<start.y<<','<<start.orien<<std::endl;
	std::cout<<"Goal : "<<goal.x<<','<<goal.y<<','<<goal.orien<<std::endl;
	std::cout<<"------------------"<<std::endl;

	clock_t t1, t2;
	t1 = clock();
	std::vector<Node> path;
	ast.initialize(start, goal);
	bool retAstar = ast.genTrajectory(path);
	t2 = clock();

	nav_msgs::Path pathForwardMsg;
	if(retAstar){
		std::cout<<"Time : "<<float(t2-t1)/CLOCKS_PER_SEC<<std::endl;
		std::cout<<"Shortest Cost : "<<path[path.size()-1].g<<std::endl;
		std::cout<<"Astar Generated"<<std::endl;
		std::cout<<"Publishing Path"<<std::endl;
		std::cout<<"------------------"<<std::endl;

		nav_msgs::Path pathMsg, pathMsgForward;
		FluxMsgs::NodeArray pathNodeArray, pathNodeArrayForward;
		thTf.shiftNodesToMapMsg(path, pathMsg, 0);
		thTf.shiftNodesToMapMsg(path, pathMsgForward, 1);
		thTf.shiftNodesToNodeArrayMsg(path, pathNodeArray, 0);
		thTf.shiftNodesToNodeArrayMsg(path, pathNodeArrayForward, 1);

		while(ros::ok()){
			pubThorPlannerPath.publish(pathMsg);
			pubThorPlannerPathForward.publish(pathMsgForward);
			pubThorPlannerPathNodeArray.publish(pathNodeArray);
			pubThorPlannerPathNodeArrayForward.publish(pathNodeArrayForward);
		}

	}
	else{
		std::cout<<"Path Generation Failed"<<std::endl;
		std::cout<<"------------------"<<std::endl;
		return 0;
	}

	return 0;
}



// make sure to transform the points from front to back while using it in Thor. (shiftFrontToBack)