#include <iostream>
#ifndef DATAH
#define DATAH
#include "Eigen/Dense"
#include <bitset>
#include <vector>
#include "FluxMsgs/Node.h"
#include "FluxMsgs/NodeArray.h"

const float PI = 3.141592653589793238;


class Node{
public:
	float x, y, z = 0, orien;
	float g, f;
	int ind, parent;
	float delta, velocity;					// these values have to be given at parent node's location to get current node.
	int velConstraint = -1;
	float time;

	Node(){}
	Node(float x_, float y_, float orien_) : x(x_), y(y_), orien(orien_){}
	Node(float x_, float y_, float z_, float orien_) : x(x_), y(y_), z(z_), orien(orien_){}
	void makeNode(float x_, float y_, float orien_){
		x = x_;
		y = y_;
		orien = orien_;
	}

};

namespace VehicleData{
	const float Length = 1.45;
	const float Width = 1.186;
	const float DeltaMax = PI/3;
	const float DeltaMin = -PI/3;
	const float DeltaDot = PI/12;
	const std::vector<Node> EndPoints{Node(-0.253, 0.593,0), Node(1.742, 0.593, 0), Node(1.742, -0.593, 0), Node(-0.253, -0.593, 0), Node(-0.253, 0.593,0)};	//do not change the order.
	// these are locaions of corners of robot w.r.t rear axle center.
}

namespace AstarData{
	// const float ActionLength = 0.3;
	const float ActionLength = 0.2;

	const float ActionDeltaMax = VehicleData::DeltaMax;
	const float ActionDeltaMin = VehicleData::DeltaMin;
	const float ActionAngResForward = PI/18;	//10 degrees
	const float ActionAngResBackward = PI/3;	//30 degrees, 
	// the backward ang resolution should always be the multiple of forward ang resolution,
	// because the angles created by series of actions should always comes in multiples of ang resolution
	// so that it'd be unique to generate the indices for storing in the 3D Dictionary matrix.

	const float GoalReachThreshold = 0.2;
	const float ActionVelocity = 1;
	const uint OrientationSize = 2*PI/ActionAngResForward;
	const float GoalOrientationOffset = 1.2*ActionAngResForward;
	const float VehicleEdgeResolution = 0.05;		// resolution used for discretizing the edge for checking the collision.
}

namespace TuningParams{
//tuning these values helps to generate path away from map edges and corners.
	const float VehicleElongationFactor = 1.0;
	const uint MapDilationNum = 0;
	const float ActionDeltaCostFactor = 0.5;
	const uint Heuristic = 3;
	// 1 = euclidean distance
	// 2 = euclidean distance + brushfire (the HeuristicCostsGrassFireFactor should be 0 and tune the HeuristicCostsBrushFireFactor)
	// 3 = brushfire + grassfire

// if the grassfire and brushfire costs are used then tune these values
	// const float HeuristicCostsBrushFireFactor = 15;
	// const float HeuristicCostsGrassFireFactor = 1;

	const float HeuristicCostsBrushFireFactor = 10;
	const float HeuristicCostsGrassFireFactor = 1;
// adjust the BrushFire costs and 'g' cost to obtain a refined path according to requirements.

	const int nPtsLocalPath = 20; 	// do not assign more than 20.
	const int PathExtensionNumPts = 1;	// this will be used for getting 'PathExtensionNumPts' number of extra points from the given output points from Astar
	// it'll be done by executing action at each point and extracting more number of points through out the action.

	const int extraPts = 3;				// adding extra points between two consecutive points, if the distance is more.

	const uint VehicleDirection = 1;
	// 1 for forward
	// 2 for backward
	// 3 for both forward and backward

}
// adjust the g values for forward and reverse motions priorities.

// /home/santosh_thati/Documents/FluxAuto/ThorPlanner_ws/src/ThorPlannerv2/include/Map/OfficeMap.png

// get these params from map yaml file.
// namespace MapData{
// 	const std::string MapAddress = "/home/santosh_thati/Documents/FluxAuto/ThorPlanner_ws/src/map/warehouse/warehouse2.pgm";
// 	// const std::string MapAddress = "/home/santosh_thati/Documents/FluxAuto/ThorPlanner_ws/src/map/test6.pgm";
// 	const float MapRes = 0.05;

// 	// const float OriginX = -0.7;
// 	// const float OriginY = -0.35;
// 	// const float OriginOrien = -0.12;

// 	const float OriginX = -2.690658492258806;
// 	const float OriginY = 27.20538536667055;
// 	const float OriginOrien = -1.5;

// 	const bool Negate = 0;
// 	const float OccupiedThresh = 0.65;
// 	const float FreeThresh = 0.196;

// }

namespace MapData{
	std::string MapAddress;
	float OccupiedThresh;
	float FreeThresh;
	bool Negate;
	float MapRes;
	float OriginX;
	float OriginY;
	float OriginOrien;
}



namespace PurePursuitData{
	const uint LookAheadIndex = 2;
	const float TimeStep = 0.1;
	const float ExitOffset = 1;
}

#include "func.h"

#endif