#ifndef ASTARH
#define ASTARH

#include <iostream>
#include <cmath>
#include <unordered_map>
#include "Eigen/Dense"
#include "kdtree.h"
#include <algorithm>
#include "Data.h"
#include "obsCostMap.h"
#include "grassfire.h"


class Astar{
	cv::Mat map;
	Node goalDest, startPt;
	std::vector<Node> treeData;
	Eigen::MatrixXf heuristicCost;
	std::vector<Node> boundaryPts, boundaryElongPts;
	std::vector<float> deltaAction;
	std::vector<AstarAction> actions;

	float goal_threshold = AstarData::GoalReachThreshold;
	std::vector<Node> endVehPts = VehicleData::EndPoints;
	std::vector<Node> endPts;

	float actionTime = AstarData::ActionLength;
	float L = VehicleData::Length;
	float velocity = AstarData::ActionVelocity;
	float DeltaMax = AstarData::ActionDeltaMax;
	float DeltaMin = AstarData::ActionDeltaMin;
	float vehElongFact = TuningParams::VehicleElongationFactor;
	uint euc = TuningParams::Heuristic;
	float goalOrienOff = AstarData::GoalOrientationOffset;

public:
	Astar(){}
	Astar(cv::Mat& map_){
		if(TuningParams::MapDilationNum > 0)
			cv::dilate(map_, map, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(TuningParams::MapDilationNum, TuningParams::MapDilationNum)));
		else
			map = map_;

		genBoundaryPts();
		genActions();
	}

	void initialize(Node start, Node goal){

		// std::cout<<"a"<<std::endl;

		cv::Mat mapC = map.clone();

		clock_t t1, t2;
		t1 = clock();
		// std::cout<<"b"<<std::endl;
	//brushfire
		Eigen::MatrixXf matCostsBrush = std::numeric_limits<float>::infinity()*Eigen::MatrixXf::Ones(mapC.rows,mapC.cols);
		Eigen::MatrixXf matCosts;
		ObsCostMap ocm(mapC);
		ocm.genCostMap(matCostsBrush);

		t2 = clock();
		std::cout<<"Time OCM : "<<float(t2-t1)/CLOCKS_PER_SEC<<std::endl;
		// ocm.dispCosts(matCostsBrush);
		// std::cout<<"c"<<std::endl;



		clock_t t3, t4;
		t3 = clock();
	//grassfire
		// std::cout<<"ce"<<std::endl;
		// std::cout<<"MapC : "<<mapC.cols<<", "<<mapC.rows<<std::endl;
		Eigen::MatrixXf matCostsGrass = std::numeric_limits<float>::infinity()*Eigen::MatrixXf::Ones(mapC.rows,mapC.cols);
		// std::cout<<"cf"<<std::endl;
		GrassFire gf(mapC, goal);
		// std::cout<<"cg"<<std::endl;
		gf.genCosts(matCostsGrass);
		// std::cout<<"d"<<std::endl;
		t4 = clock();
		std::cout<<"Time GrassFire : "<<float(t4-t3)/CLOCKS_PER_SEC<<std::endl;

		float wBrush = TuningParams::HeuristicCostsBrushFireFactor;
		float wGrass = TuningParams::HeuristicCostsGrassFireFactor;
		matCosts = wBrush*matCostsBrush + wGrass*matCostsGrass;
		// std::cout<<"e"<<std::endl;

		heuristicCost = matCosts;

		// std::cout<<"f"<<std::endl;
		goalDest = goal;
		goalDest.x = goal.x*MapData::MapRes;
		goalDest.y = goal.y*MapData::MapRes;
		goalDest.orien =  goal.orien;
		// std::cout<<"g"<<std::endl;

		startPt = start;
		startPt.x = start.x*MapData::MapRes;
		startPt.y = start.y*MapData::MapRes;
		startPt.orien = start.orien;

		// std::cout<<"h"<<std::endl;

	}

	void genActions(){
		if(TuningParams::VehicleDirection == 1 || TuningParams::VehicleDirection == 3){
			for(float del = DeltaMin;del < DeltaMax + PI/360;del += AstarData::ActionAngResForward){
				std::vector<Node> pts;
				genEdgePts(del, velocity, actionTime, pts);
				actions.push_back(AstarAction(del, velocity, actionTime, pts));
			}			
		}

		if(TuningParams::VehicleDirection == 2 || TuningParams::VehicleDirection == 3){
			for(float del = DeltaMin;del < DeltaMax + PI/360;del += AstarData::ActionAngResBackward){	//once check the Data.h for tuning these values and see the description before tuning.
				std::vector<Node> pts;
				genEdgePts(del, -velocity, actionTime, pts);
				actions.push_back(AstarAction(del, -velocity, actionTime, pts));
			}
		}
	}

	void genBoundaryPts(){
		for(int i = 0;i < endVehPts.size();i++)
			endPts.push_back(Node(endVehPts[i].x*vehElongFact, endVehPts[i].y*vehElongFact, 0));

		boundaryPts.clear();
		boundaryPts.push_back(endPts[0]);

		for(int i = 1;i < endPts.size();i++){
			int numPts = 6 + i%2;
			for(int alpha = 1;alpha <= numPts;alpha++){
				float x = (1.0 - alpha/float(numPts))*endPts[i-1].x + (alpha/float(numPts))*endPts[i].x;
				float y = (1.0 - alpha/float(numPts))*endPts[i-1].y + (alpha/float(numPts))*endPts[i].y;
				boundaryPts.push_back(Node(x, y, 0));
			}
		}

		boundaryElongPts.clear();
		boundaryElongPts.push_back(endVehPts[0]);
		for(int i = 1;i < endVehPts.size();i++){
			int numPts = 6 + i%2;
			for(int alpha = 1;alpha <= numPts;alpha++){
				float x = (1.0 - alpha/float(numPts))*endVehPts[i-1].x + (alpha/float(numPts))*endVehPts[i].x;
				float y = (1.0 - alpha/float(numPts))*endVehPts[i-1].y + (alpha/float(numPts))*endVehPts[i].y;
				boundaryElongPts.push_back(Node(x, y, 0));
			}
		}
	}

	void genEdge(Node& n1, Node& n2, std::vector<Node>& pts){
		float dist = Distance(n1, n2);
		int nPts = dist/0.1;	// generating points with 0.1 gap.

		for(int i = 0;i <= nPts;i++)
			pts.push_back(Node((1 - i/float(nPts))*n1.x + i*n2.x/float(nPts), (1 - i/float(nPts))*n1.y + i*n2.y/float(nPts), 0));
	}

	void genEdgePts(float delta, float vel, float ti, std::vector<Node>& pts){	//doesn't work in reverse case, check it.
		pts.clear();
		std::vector<Node> pts0, pts1, pts2, pts3, pts4, pts5;

		uint pt0_ind, pt1_ind, pt2_ind, pt3_ind;
		pt0_ind = delta < 0 && velocity > 0 ? 0 : 3;
		pt1_ind = delta < 0 && velocity > 0 ? 1 : 2;
		pt2_ind = delta < 0 && velocity > 0 ? 2 : 1;
		pt3_ind = delta < 0 && velocity > 0 ? 3 : 0;

		pt0_ind = delta < 0 && velocity < 0 ? 2 : 1;
		pt1_ind = delta < 0 && velocity < 0 ? 3 : 0;
		pt2_ind = delta < 0 && velocity < 0 ? 0 : 3;
		pt3_ind = delta < 0 && velocity < 0 ? 1 : 2;

		genEdge(endPts[pt0_ind],endPts[pt1_ind],pts0);
		genEdge(endPts[pt3_ind],endPts[pt0_ind],pts5);

		Node pt, pt1, pt2, pt3;
		int nPts = std::fabs(vel)*ti/AstarData::VehicleEdgeResolution;
		for(int i = 0;i <= nPts;i++){
			pt = executeAction(Node(0,0,0), delta, vel, ti*i/float(nPts));
			pt1 = shiftFrame(pt, endPts[pt1_ind]);
			pt3 = shiftFrame(pt, endPts[pt3_ind]);

			pts1.push_back(pt1);
			pts4.push_back(pt3);
		}
		pt2 = shiftFrame(pt, endPts[pt2_ind]);

		genEdge(pt1, pt2, pts2);
		genEdge(pt2, pt3, pts3);

		std::reverse(pts4.begin(), pts4.end());
		pts.insert(pts.end(), pts0.begin(), pts0.end());
		pts.insert(pts.end(), pts1.begin(), pts1.end());
		pts.insert(pts.end(), pts2.begin(), pts2.end());
		pts.insert(pts.end(), pts3.begin(), pts3.end());
		pts.insert(pts.end(), pts4.begin(), pts4.end());
		pts.insert(pts.end(), pts5.begin(), pts5.end());
	}

	bool isIn(Node& n){
		if(n.x < 0 || n.y < 0 || n.x >= map.cols*MapData::MapRes || n.y >= map.rows*MapData::MapRes || map.at<uchar>(n.y/MapData::MapRes,n.x/MapData::MapRes) < 50)
			return true;
		else
			return false;
	}

	Node shiftFrame(Node& orig, Node& n){
		Node shiftNode;

		shiftNode.x = n.x*cos(-orig.orien) + n.y*sin(-orig.orien) - (-orig.x);
		shiftNode.y = -n.x*sin(-orig.orien) + n.y*cos(-orig.orien) - (-orig.y);
		shiftNode.orien = n.orien - orig.orien;
		shiftNode.orien = (inRo(shiftNode.orien*180/PI)%360)*PI/180;

		return shiftNode;
	}

	bool CollisionCheck(Node& n){
		if(!isIn(n))
			return true;

		return false;
	}

	bool CollisionCheckRobot(Node& n){
		for(int i = 0;i < boundaryPts.size();i++){
			Node shiftBoundPt = shiftFrame(n, boundaryPts[i]);
			if(CollisionCheck(shiftBoundPt))
				return true;
		}

		return false;
	}

	bool CollisionCheckAction(Node& n, AstarAction& act){
		for(int i = 0;i < act.boundaryPts.size();i++){
			Node shiftBoundPt = shiftFrame(n, act.boundaryPts[i]);
			if(CollisionCheck(shiftBoundPt))
				return true;
		}

		return false;
	}

	void DispVehicle(cv::Mat& imgDisp, Node loc){
		std::cout<<loc.x<<','<<loc.y<<std::endl;
		cv::circle(imgDisp,cv::Point(loc.x/MapData::MapRes, loc.y/MapData::MapRes),3,255,-1);
		for(int j = 0;j < boundaryElongPts.size();j++){
			Node shiftBoundPt = shiftFrame(loc, boundaryElongPts[j]);
			cv::circle(imgDisp,cv::Point(shiftBoundPt.x/MapData::MapRes,shiftBoundPt.y/MapData::MapRes),2,155,-1);
		}

		cv::imshow("img",imgDisp);
		cv::waitKey(0);
	}


	void CollisionSimulate(cv::Mat& imgSim, std::vector<Node> pts, uint color, uint waitTime){
		for(int i = 0;i < pts.size();i++)
			cv::circle(imgSim,cv::Point(pts[i].x/MapData::MapRes,pts[i].y/MapData::MapRes),3,color,-1);

		for(int i = 0;i < pts.size();i++){
			cv::Mat imgSimDisp = imgSim.clone();
			cv::circle(imgSimDisp,cv::Point(pts[i].x/MapData::MapRes, pts[i].y/MapData::MapRes),3,255,-1);
			for(int j = 0;j < boundaryElongPts.size();j++){
				Node shiftBoundPt = shiftFrame(pts[i], boundaryElongPts[j]);
				cv::circle(imgSimDisp,cv::Point(shiftBoundPt.x/MapData::MapRes,shiftBoundPt.y/MapData::MapRes),2,155,-1);
			}

			cv::imshow("image",imgSimDisp);
			uint key = cv::waitKey(waitTime);
			if(key == 27)
				break;
		}

		cv::waitKey(0);
	}

	float calHeuristic(Node& n){
		switch (euc){			
			case 1:	//euclidean distance
				return Distance(n, goalDest)/velocity;
			case 2: //euclidean distance + brushfire
				return Distance(n, goalDest)/velocity + heuristicCost(n.y/MapData::MapRes, n.x/MapData::MapRes)/velocity;
			case 3: //brushfire + grassfire
				return heuristicCost(n.y/MapData::MapRes, n.x/MapData::MapRes)/velocity;
		}
	}

	Node executeAction(Node curr, float delta, float vel, float ti){
		Node next;
		float orien = curr.orien + vel*tan(delta)*ti/L;
		next.orien = (inRo(orien*180/PI)%360)*PI/180;

		if(round(delta*180/PI) != 0){
			next.x = curr.x + L*(sin(next.orien) - sin(curr.orien))/tan(delta);
			next.y = curr.y + L*(cos(curr.orien) - cos(next.orien))/tan(delta);
		}
		else{
			next.x = curr.x + vel*cos(curr.orien)*ti;
			next.y = curr.y + vel*sin(curr.orien)*ti;
		}

		return next;
	}


		// std::cout<<"a"<<std::endl;
		// std::cout<<"b"<<std::endl;
		// std::cout<<"c"<<std::endl;
		// std::cout<<"d"<<std::endl;
		// std::cout<<"e"<<std::endl;
		// std::cout<<"f"<<std::endl;
		// std::cout<<"g"<<std::endl;
		// std::cout<<"h"<<std::endl;

	void genSuccessorsBicycle(Node& curr, std::vector<Node>& successors){
		successors.clear();
		for(int i = 0;i < actions.size();i++){
			Node succ = executeAction(curr, actions[i].delta, actions[i].velocity, actionTime);
			bool val = CollisionCheckAction(curr, actions[i]);


			succ.g = curr.g + actionTime + TuningParams::ActionDeltaCostFactor*std::fabs(actions[i].delta);
			succ.ind = treeData.size();
			succ.parent = curr.ind;
			succ.delta = actions[i].delta;
			succ.velocity = actions[i].velocity;
			succ.time = curr.time + actions[i].cost;

			if(!val){
				succ.f = succ.g + calHeuristic(succ);
				treeData.push_back(succ);
				successors.push_back(succ);
			}
		}
	}

	void getPath(Node& node, std::vector<Node>& path){
		path.clear();
		Node curr = node;
		while(true){
			path.push_back(curr);
			if(curr.parent < 0)
				break;

			curr = treeData[curr.parent];
		}
		std::reverse(path.begin(),path.end());

		path[0].velocity = path[1].velocity;		
// the start node will have forward velocity, but the next point could be backward, so adjusted it to next point's velocity.

		int nExtraPts = TuningParams::extraPts;
		for(int i = 0;i < path.size()-1;i++){
			float timeDiff = (path[i+1].time - path[i].time)/(nExtraPts+1);
			for(int j = 1;j < nExtraPts+1;j++){			
				Node n = executeAction(path[i], path[i+1].delta, path[i+1].velocity, timeDiff);
				n.g = path[i].g + timeDiff;
				n.f = n.g + calHeuristic(n);
				n.ind = treeData.size();
				n.parent = path[i].ind;
				n.delta = path[i].delta;
				n.velocity = path[i+1].velocity;
				n.time = path[i].time + timeDiff;
				treeData.push_back(n);

				if(j == nExtraPts)
					path[i+1].parent = n.ind;

				path.insert(path.begin()+i+1, n);
				i++;
			}

		}

		for(int i = 0;i < path.size();i++){
			path[i].x /= MapData::MapRes;
			path[i].y /= MapData::MapRes;
		}

	}

	float angBetNodes(Node& n1, Node& n2){
		return acos(cos(n1.orien)*cos(n2.orien) + sin(n1.orien)*sin(n2.orien));
	}

	bool genTrajectory(std::vector<Node>& path){
		// st.x *= MapData::MapRes;
		// st.y *= MapData::MapRes;
		// gl.x *= MapData::MapRes;
		// gl.y *= MapData::MapRes;

		Node gl = goalDest;
		Node st = startPt;
		float cost = 0;
		Node prev = gl;

		if(CollisionCheckRobot(st)){
			std::cout<<"Invalid start"<<std::endl;
			cv::Mat imgDisp = map.clone();
			DispVehicle(imgDisp, st);
			return false;
		}

		if(CollisionCheckRobot(gl)){
			std::cout<<"Invalid goal"<<std::endl;
			cv::Mat imgDisp = map.clone();
			DispVehicle(imgDisp, gl);
			return false;
		}

		cv::Mat img = map.clone();
		dispPt(img,st,5,255);
		dispPt(img,gl,5,255);


		// std::cout<<"-5"<<std::endl;
		Queue queOpen;
		Dictionary dictOpen(map.rows, map.cols);
		// std::cout<<"-4"<<std::endl;
		Dictionary dictClosed(map.rows, map.cols);

		// std::cout<<"-3"<<std::endl;
		bool solution = false;
		Node start = st;
		Node goal = gl;
		start.g = 0;
		start.f = calHeuristic(start);
		start.ind = treeData.size();
		start.parent = -1; 
		start.time = 0;
		treeData.push_back(start);

		// std::cout<<"-2"<<std::endl;
		queOpen.push(start);
		dictOpen.add(start);

		// std::cout<<"-1"<<std::endl;
		std::vector<Node> nodeCurrSuccessors;
		Node nodeCurr;
		
		
		// std::cout<<"1"<<std::endl;
		bool visualize = false;
		while(queOpen.length()){
		// std::cout<<"2"<<std::endl;
			nodeCurr = queOpen.pop();
			dictOpen.remove(nodeCurr);

		// std::cout<<"3"<<std::endl;
			if(visualize){
				dispPt(img,nodeCurr,3,155);
				cv::circle(img,cv::Point(nodeCurr.x/MapData::MapRes,nodeCurr.y/MapData::MapRes),3,155,-1);
				cv::imshow("image",img);
				uint key = cv::waitKey(1);
				if(key == 27)
					break;
				if(key == 32)
					cv::waitKey(0);
			}
			// std::cout<<"4"<<std::endl;

			// if(Distance(nodeCurr,goal) < goal_threshold){
			bool goalReach = Distance(nodeCurr,goal) < goal_threshold;
			if(Distance(nodeCurr,goal) < goal_threshold  angBetNodes(goal, nodeCurr) < goalOrienOff){
				solution = true;
				getPath(nodeCurr,path);
				break;
			}

			// bool goalReach = Distance(nodeCurr,goal) < goal_threshold;
			// if(TuningParams::considerGoalOrientation)
			// 	goalReach = goalReach && angBetNodes(goal, nodeCurr) < goalOrienOff;

			// if(goalReach){
			// 	solution = true;
			// 	getPath(nodeCurr,path);
			// 	break;
			// }
		// std::cout<<"5"<<std::endl;

			dictClosed.add(nodeCurr);
			genSuccessorsBicycle(nodeCurr,nodeCurrSuccessors);
			for(int i = 0;i < nodeCurrSuccessors.size();i++){
		// std::cout<<"5a"<<std::endl;
				Node nodeSucc = nodeCurrSuccessors[i];
				bool valOpen = dictOpen.isAvailable(nodeSucc);
				bool valClosed = dictClosed.isAvailable(nodeSucc);

		// std::cout<<"5b"<<std::endl;
				if(!valClosed){
		// std::cout<<"6"<<std::endl;
					if(!valOpen){
		// std::cout<<"7"<<std::endl;
						queOpen.push(nodeSucc);
						dictOpen.add(nodeSucc);
		// std::cout<<"8"<<std::endl;
					}
					else{
		// std::cout<<"9"<<std::endl;
						int openSuccInd = dictOpen.get(nodeSucc);
		// std::cout<<"10"<<std::endl;

						Node& openSucc = treeData[openSuccInd];
		// std::cout<<"11"<<std::endl;
						if(nodeSucc.g < openSucc.g){
		// std::cout<<"12"<<std::endl;
							queOpen.push(nodeSucc);
							dictOpen.add(nodeSucc);
		// std::cout<<"13"<<std::endl;
						}
		// std::cout<<"14"<<std::endl;
					}
		// std::cout<<"15"<<std::endl;
				}
		// std::cout<<"16"<<std::endl;
			}
		// std::cout<<"17"<<std::endl;
		}

		std::cout<<"Total Nodes : "<<treeData.size()<<std::endl;
		treeData.clear();
		return solution;
	}
};





// write a heuristic function using the each action state.
		// std::cout<<"4"<<std::endl;
		// std::cout<<"A*"<<std::endl;
		// std::cout<<"--------------------"<<std::endl;
		// std::cout<<"T1 : "<<t1*1000<<", T1 avg : "<<t1*1000/n1<<", N : "<<n1<<std::endl;
		// std::cout<<"T2 : "<<t2*1000<<", T2 avg : "<<t2*1000/n2<<", N : "<<n2<<std::endl;
		// std::cout<<"T3 : "<<t3*1000<<", T3 avg : "<<t3*1000/n3<<", N : "<<n3<<std::endl;
		// std::cout<<"T4 : "<<t4*1000<<", T4 avg : "<<t4*1000/n4<<", N : "<<n4<<std::endl;
		// std::cout<<"-----"<<std::endl;
		// std::cout<<"T5 : "<<t5*1000<<", T5 avg : "<<t5*1000/n5<<", N : "<<n5<<std::endl;
		// std::cout<<" T6 : "<<t6*1000<<", T6 avg : "<<t6*1000/n6<<", N : "<<n6<<std::endl;
		// std::cout<<" T7 : "<<t7*1000<<", T7 avg : "<<t7*1000/n7<<", N : "<<n7<<std::endl;
		// std::cout<<" T8 : "<<t8*1000<<", T8 avg : "<<t8*1000/n8<<", N : "<<n8<<std::endl;
		// std::cout<<" T9 : "<<t9*1000<<", T9 avg : "<<t9*1000/n9<<", N : "<<n9<<std::endl;
		// std::cout<<" T10 : "<<t1*1000<<"T10 avg : "<<t10*1000/n10<<", N : "<<n10<<std::endl;;
		// std::cout<<"-----"<<std::endl;
		// // std::cout<<"Open List Size : "<<dictOpen.size()<<std::endl;
		// // std::cout<<"Closed List Size : "<<dictClosed.size()<<std::endl;
		// std::cout<<"--------------------"<<std::endl;
		// std::cout<<"--------------------"<<std::endl;
		// std::cout<<"3"<<std::endl;
		// to1 = clock();
		// std::cout<<"4"<<std::endl;
		// to2 = clock();
		// std::cout<<"Open : "<<float(to2-to1)/CLOCKS_PER_SEC <<std::endl;
		// std::cout<<"5"<<std::endl;
		// std::cout<<"Closed : "<<float(tc2-tc1)/CLOCKS_PER_SEC <<std::endl;
		// std::cout<<"6"<<std::endl;
		// float t1=0,t2=0,t3=0,t4=0,t5=0,t6=0,t7=0,t8=0,t9=0,t10=0;
		// int n1=0,n2=0,n3=0,n4=0,n5=0,n6=0,n7=0,n8=0,n9=0,n10=0;
		// clock_t t11,t12;
		// t11 = clock();
		// t12 = clock();
		// t1 += float(t12-t11)/CLOCKS_PER_SEC;
		// n1++;
		// clock_t t21,t22;
		// t21 = clock();
		// t22 = clock();
		// t2 += float(t22-t21)/CLOCKS_PER_SEC;
		// n2++;
		// clock_t t31,t32;
		// t31 = clock();
		// t32 = clock();
		// t3 += float(t32-t31)/CLOCKS_PER_SEC;
		// n3++;
		// clock_t t41,t42;
		// t41 = clock();
		// t42 = clock();
		// t4 += float(t42-t41)/CLOCKS_PER_SEC;
		// n4++;
		// clock_t t51,t52;
		// t51 = clock();
		// t52 = clock();
		// t5 += float(t52-t51)/CLOCKS_PER_SEC;
		// n5++;
		// clock_t t61,t62;
		// t61 = clock();
		// t62 = clock();
		// t6 += float(t62-t61)/CLOCKS_PER_SEC;
		// n6++;
		// clock_t t71,t72;
		// t71 = clock();
		// t72 = clock();
		// t7 += float(t72-t71)/CLOCKS_PER_SEC;
		// n7++;
		// clock_t t81,t82;
		// t81 = clock();
		// t82 = clock();
		// t8 += float(t82-t81)/CLOCKS_PER_SEC;
		// n8++;
		// clock_t t91,t92;
		// t91 = clock();
		// t92 = clock();
		// t9 += float(t92-t91)/CLOCKS_PER_SEC;
		// n9++;
		// clock_t t101,t102;
		// t101 = clock();
		// t102 = clock();
		// t10 += float(t102-t101)/CLOCKS_PER_SEC;
		// n10++;


#endif