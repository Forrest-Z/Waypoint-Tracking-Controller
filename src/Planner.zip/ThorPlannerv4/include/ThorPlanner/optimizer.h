#include <iostream>
#include <cmath>
#include "func.h"
#include "Data.h"


class Optimization{
public:
	double w_obsColl = 0.2;
	double w_obsPushAway = 0.2;
	double w_smth = 0.4;
	double dmax = 0.75/MapData::MapRes;

	cv::Mat map;
	uint MapWidth, MapHeight;
	std::vector<Node> endVehPts = VehicleData::EndPoints;
	std::vector<Node> endPts;
	std::vector<Node> boundaryPts, boundaryVehPts;
	float vehElongFact = TuningParams::VehicleElongationFactor;
	Eigen::MatrixXf& matCosts;
	ObsCostMap ocm;

	Optimization(Eigen::MatrixXf& matCosts_, cv::Mat& map_, ObsCostMap& ocm_) : map(map_), matCosts(matCosts_), ocm(ocm_){
		MapWidth = map.cols;
		MapHeight = map.rows;
		genBoundaryPts();
	}

	void genBoundaryPts(){
		for(int i = 0;i < endVehPts.size();i++)
			endPts.push_back(Node(endVehPts[i].x*vehElongFact, endVehPts[i].y*vehElongFact, 0));

		boundaryPts.clear();
		boundaryPts.push_back(endPts[0]);

		for(int i = 1;i < endPts.size();i++){
			int numPts = 6 + i%2;
			for(int alpha = 1;alpha <= numPts;alpha++){
				float x = (1.0 - alpha/float(numPts))*endPts[i-1].x + (alpha/float(numPts))*endPts[i].x;
				float y = (1.0 - alpha/float(numPts))*endPts[i-1].y + (alpha/float(numPts))*endPts[i].y;
				boundaryPts.push_back(Node(x, y, 0));
			}
		}

		boundaryVehPts.clear();
		boundaryVehPts.push_back(endVehPts[0]);
		for(int i = 1;i < endVehPts.size();i++){
			int numPts = 6 + i%2;
			for(int alpha = 1;alpha <= numPts;alpha++){
				float x = (1.0 - alpha/float(numPts))*endVehPts[i-1].x + (alpha/float(numPts))*endVehPts[i].x;
				float y = (1.0 - alpha/float(numPts))*endVehPts[i-1].y + (alpha/float(numPts))*endVehPts[i].y;
				boundaryVehPts.push_back(Node(x, y, 0));
			}
		}
	}

	bool isIn(Node& n){
		if(n.x < 0 || n.y < 0 || n.x >= MapWidth*MapData::MapRes || n.y >= MapHeight*MapData::MapRes || map.at<uchar>(n.y/MapData::MapRes, n.x/MapData::MapRes) < 50)
			return true;
		else
			return false;
	}

	bool CollisionCheck(Node& n){
		if(!isIn(n))
			return true;

		return false;
	}

	bool CollisionCheckRobot(Node& n){
		std::vector<Node> shiftBoundPts;
		for(int i = 0;i < boundaryPts.size();i++){
			Node shiftBoundPt = shiftFrame(n, boundaryPts[i]);
			if(CollisionCheck(shiftBoundPt))
				return true;
		}

		return false;
	}

	Node shiftFrame(Node& orig, Node& n){
		Node shiftNode;

		shiftNode.x = n.x*cos(-orig.orien) + n.y*sin(-orig.orien) - (-orig.x);
		shiftNode.y = -n.x*sin(-orig.orien) + n.y*cos(-orig.orien) - (-orig.y);
		shiftNode.orien = n.orien - orig.orien;
		shiftNode.orien = (inRo(shiftNode.orien*180/PI)%360)*PI/180;

		return shiftNode;
	}

	Node partDerObsPiece(Node& xi){
		Node pt_iR = inRo(xi);
		Node oi = ocm.getNearPt(pt_iR);
		Node deriv;

		if(Distance(xi,oi) != 0){
			double deriv_k = this->w_obsColl/Distance(xi,oi);
			double deriv_1 = deriv_k*(xi.x - oi.x);
			double deriv_2 = deriv_k*(xi.y - oi.y);
			deriv.x = deriv_1;
			deriv.y = deriv_2;
		}

		else{
			deriv.x = 0;
			deriv.y = 0;}

		return deriv;
	}

	void dispRobot(Node& n){
		cv::Mat img = map.clone();

		cv::circle(img, cv::Point(n.x/MapData::MapRes, n.y/MapData::MapRes),2,155,-1);
		for(int i = 0;i < boundaryPts.size();i++){
			Node shiftBoundPt = shiftFrame(n, boundaryPts[i]);
			cv::circle(img, cv::Point(shiftBoundPt.x/MapData::MapRes, shiftBoundPt.y/MapData::MapRes),2,155,-1);
		}
		cv::imshow("Image",img);
		cv::waitKey(0);

	}

	Node partDerObsCollision(Node& n){
		std::vector<Node> shiftBoundPts;
		Node partDerColl(0,0,0);

		for(int i = 0;i < boundaryPts.size();i++){
			Node shiftBoundPt = shiftFrame(n, boundaryPts[i]);
			// dispRobot(n);
			if(CollisionCheckRobot(shiftBoundPt)){
				Node partDerObsPiece(shiftBoundPt);
				partDerColl.x += w_obsColl*partDerObsPiece.x;
				partDerColl.y += w_obsColl*partDerObsPiece.y;
			}
		}

		return partDerColl;
	}

	Node partDerObsPushAway(Node xi){
		Node oi = ocm.getNearPt(xi);
		Node deriv;

		float distxioi = Distance(xi,oi);
		if(distxioi < this->dmax && distxioi != 0){
			double deriv_k = 2*this->w_obsPushAway*(distxioi - this->dmax)/Distance(xi,oi);
			double deriv_1 = deriv_k*(xi.x - oi.x);
			double deriv_2 = deriv_k*(xi.y - oi.y);
			deriv.x = deriv_1;
			deriv.y = deriv_2;
		}

		else{
			deriv.x = 0;
			deriv.y = 0;}

		return deriv;
	}

	Node partDerSmth(int i,std::vector<Node>& path_pts){
		Node deriv;
		double deriv_1, deriv_2;

		if(i == 0 || i == path_pts.size() - 1){
			deriv_1 = 0;
			deriv_2 = 0;
		}

		else if(i == 1){
			deriv_1 = 2*this->w_smth*(path_pts[i+2].x - 4*path_pts[i+1].x + 5*path_pts[i].x - 2*path_pts[i-1].x);
			deriv_2 = 2*this->w_smth*(path_pts[i+2].y - 4*path_pts[i+1].y + 5*path_pts[i].y - 2*path_pts[i-1].y);}

		else if(i > 1 && i < path_pts.size() - 2){
			deriv_1 = 2*this->w_smth*(path_pts[i+2].x - 4*path_pts[i+1].x + 6*path_pts[i].x - 4*path_pts[i-1].x + path_pts[i-2].x);
			deriv_2 = 2*this->w_smth*(path_pts[i+2].y - 4*path_pts[i+1].y + 6*path_pts[i].y - 4*path_pts[i-1].y + path_pts[i-2].y);}

		else if(i == path_pts.size() - 2){
			deriv_1 = 2*this->w_smth*(-2*path_pts[i+1].x + 5*path_pts[i].x - 4*path_pts[i-1].x + path_pts[i-2].x);
			deriv_2 = 2*this->w_smth*(-2*path_pts[i+1].y + 5*path_pts[i].y - 4*path_pts[i-1].y + path_pts[i-2].y);}

		deriv.x = deriv_1;
		deriv.y = deriv_2;

		return deriv;
	}

	void genOptima(std::vector<Node>& path_pts, std::vector<Node>& pathOpt){
		std::vector<Node> path_opt = path_pts;
		int itr_max = 150;
		double alpha_lr = 0.00001;

		for(int itr = 1;itr <= itr_max;itr++){
			std::vector<Node> path_opt_next;

			if(itr != 0 && itr%10 == 0){
				std::cout<<"Pure P : "<<itr<<std::endl;
				// PurePursuit obj_pp(stGo.first,init_orien,stGo.second,path_opt);
				// path_opt = obj_pp.genPursuit();
			}

			for(int i = 0;i < path_opt.size();i++){
				Node pt = path_opt[i];

				Node pd_obs_push_away = partDerObsPushAway(pt);
				Node pd_smth = partDerSmth(i,path_opt);

				Node pd_obs_coll(0,0,0);
				// pd_obs_coll = partDerObsCollision(pt);
				// std::cout<<"Obs Coll : "<<pd_obs_coll.x<<','<<pd_obs_coll.y<<std::endl;

				Node pt_new(pt.x - alpha_lr*(pd_obs_push_away.x + pd_smth.x + pd_obs_coll.x), pt.y - alpha_lr*(pd_obs_push_away.y + pd_smth.y + pd_obs_coll.y),0);
				path_opt_next.push_back(pt_new);
			}

			path_opt = path_opt_next;
			std::cout<<"EpOch : "<<itr<<std::endl;

		}

		pathOpt.clear();
		pathOpt = path_opt;
		// cv::Mat imgD = img.clone();
		// for(int i = 0;i < path_opt.size();i++)
		// 	chngPix(imgD,path_opt[i],155);

		// dispImg("image",imgD,0);
	}

};
