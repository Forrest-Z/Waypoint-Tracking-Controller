#ifndef ASTARH
#define ASTARH

#include <iostream>
#include <cmath>
#include <unordered_map>
#include "func.h"
#include "Eigen/Dense"
#include "kdtree.h"
#include <algorithm>


class Astar{
	cv::Mat map;
	Node goalDest;
	std::vector<Node> treeData;
	Eigen::MatrixXf heuristicCost;
	uint DictionaryMatWidth;
	uint DictionaryMatHeight;
	std::vector<Node> boundaryPts;
	std::vector<float> deltaAction;

	float sample_length = 10*0.0275;
	float goal_threshold = sample_length;
	std::vector<Node> endPts{Node(-0.253, 0.593,0), Node(1.742, 0.593, 0), Node(1.742, -0.593, 0), Node(-0.253, -0.593, 0), Node(-0.253, 0.593,0)};	//do not change the order.
	float velocity = 1;
	float t = 0.2;
	float L = 1.45;

public:
	Astar(){}
	Astar(cv::Mat& map_, Eigen::MatrixXf& heuristicCost_) : map(map_), heuristicCost(heuristicCost_){
		DictionaryMatHeight = map.rows;
		DictionaryMatWidth = map.cols;
		genActions();
		genBoundaryPts();
	}

	void genActions(){
		float deltaMax = PI/3;
		float deltaMin = -PI/3;

		for(float del = deltaMin;del < deltaMax + PI/360;del += PI/18)
			deltaAction.push_back(del);
	}

	void genBoundaryPts(){
		boundaryPts.clear();
		boundaryPts.push_back(endPts[0]);

		for(int i = 1;i < endPts.size();i++){
			int numPts = 6 + i%2;
			for(int alpha = 1;alpha <= numPts;alpha++){
				float x = (1.0 - alpha/float(numPts))*endPts[i-1].x + (alpha/float(numPts))*endPts[i].x; 
				float y = (1.0 - alpha/float(numPts))*endPts[i-1].y + (alpha/float(numPts))*endPts[i].y;
				boundaryPts.push_back(Node(x, y, 0));
			}
		}
	}

	void genEdge(Node& n1, Node& n2, std::vector<Node>& pts){
		float dist = Distance(n1, n2);
		int nPts = dist/0.1;	// generating points with 0.1 gap.

		for(int i = 0;i <= nPts;i++)
			pts.push_back(Node((1 - i/float(nPts))*n1.x + i*n2.x/float(nPts), (1 - i/float(nPts))*n1.y + i*n2.y/float(nPts), 0));
	}

	void genEdgePts(float delta, float t, std::vector<Node>& pts){
		pts.clear();

		std::vector<Node> endPts{Node(-0.253, 0.593,0), Node(1.742, 0.593, 0), Node(1.742, -0.593, 0), Node(-0.253, -0.593, 0), Node(-0.253, 0.593,0)};	//do not change the order.
		std::vector<Node> pts0, pts1, pts2, pts3, pts4, pts5;

		uint pt0_ind = delta < 0 ? 0 : 3;
		uint pt1_ind = delta < 0 ? 1 : 2;
		uint pt2_ind = delta < 0 ? 2 : 1;
		uint pt3_ind = delta < 0 ? 3 : 0;

		genEdge(endPts[pt0_ind],endPts[pt1_ind],pts0);
		genEdge(endPts[pt3_ind],endPts[pt0_ind],pts5);

		Node pt, pt1, pt2, pt3;
		int nPts = velocity*t/0.05;
		for(int i = 0;i <= nPts;i++){
			pt = executeAction(Node(0,0,0), delta, t*i/float(nPts));
			pt1 = shiftFrame(pt, endPts[pt1_ind]);
			pt3 = shiftFrame(pt, endPts[pt3_ind]);

			pts1.push_back(pt1);
			pts4.push_back(pt3);
		}
		pt2 = shiftFrame(pt, endPts[pt2_ind]);

		genEdge(pt1, pt2, pts2);
		genEdge(pt2, pt3, pts3);

		std::reverse(pts4.begin(), pts4.end());
		pts.insert(pts.end(), pts0.begin(), pts0.end());
		pts.insert(pts.end(), pts1.begin(), pts1.end());
		pts.insert(pts.end(), pts2.begin(), pts2.end());
		pts.insert(pts.end(), pts3.begin(), pts3.end());
		pts.insert(pts.end(), pts4.begin(), pts4.end());
		pts.insert(pts.end(), pts5.begin(), pts5.end());
	}

	float Distance(Node& n1, Node& n2){
		return sqrt(pow(n1.x-n2.x,2) + pow(n1.y-n2.y,2));
	}

	float Distance(KDT::MyPoint& n1, KDT::MyPoint& n2){
		return sqrt(pow(n1[0] - n2[0],2) + pow(n1[1] - n2[1],2));
	}

	float Distance(Node& n1, KDT::MyPoint& n2){
		return sqrt(pow(n1.x - n2[0],2) + pow(n1.y - n2[1],2));
	}

	bool isIn(Node& n){
		if(n.x < 0 || n.y < 0 || n.x >= DictionaryMatWidth*0.0275 || n.y >= DictionaryMatHeight*0.0275 || map.at<uchar>(n.y/0.0275,n.x/0.0275) < 50)
			return true;
		else
			return false;
	}

	Node shiftFrame(Node& orig, Node& n){
		Node shiftNode;

		shiftNode.x = n.x*cos(-orig.orien) + n.y*sin(-orig.orien) - (-orig.x);
		shiftNode.y = -n.x*sin(-orig.orien) + n.y*cos(-orig.orien) - (-orig.y);
		shiftNode.orien = n.orien - orig.orien;
		shiftNode.orien = (inRo(shiftNode.orien*180/PI)%360)*PI/180;

		return shiftNode;
	}



	bool CollisionCheck(Node& n){
		if(!isIn(n))
			return true;

		return false;
	}

	bool CollisionCheckRobot(Node& n){
		std::vector<Node> shiftBoundPts;
		for(int i = 0;i < boundaryPts.size();i++){
			Node shiftBoundPt = shiftFrame(n, boundaryPts[i]);
			if(CollisionCheck(shiftBoundPt))
				return true;
		}

		return false;
	}

	void CollisionSimulate(cv::Mat& imgSim, std::vector<Node> pts, uint color, uint waitTime){
		// cv::Mat imgSim = map.clone();

		for(int i = 0;i < pts.size();i++)
			cv::circle(imgSim,cv::Point(pts[i].x/0.0275,pts[i].y/0.0275),3,color,-1);

		for(int i = 0;i < pts.size();i++){
			cv::Mat imgSimDisp = imgSim.clone();
			std::vector<Node> shiftBoundPts;
			cv::circle(imgSimDisp,cv::Point(pts[i].x/0.0275, pts[i].y/0.0275),5,255,-1);
			for(int j = 0;j < boundaryPts.size();j++){
				Node shiftBoundPt = shiftFrame(pts[i], boundaryPts[j]);
				cv::circle(imgSimDisp,cv::Point(shiftBoundPt.x/0.0275,shiftBoundPt.y/0.0275),2,155,-1);
			}

			cv::imshow("image",imgSimDisp);
			cv::waitKey(waitTime);
		}

		cv::waitKey(0);
	}

	// float calHeuristic(Node& n){
	// 	return 0.0275*heuristicCost(n.y/0.0275, n.x/0.0275)/velocity;
	// }

	float calHeuristic(Node& n){
		return Distance(n, goalDest)/velocity;
	}

	Node executeAction(Node curr, float delta, float t){
		Node next;

		float orien = curr.orien + velocity*tan(delta)*t/L;
		next.orien = (inRo(orien*180/PI)%360)*PI/180;

		if(delta*180/PI != 0){
			next.x = curr.x + L*(sin(next.orien) - sin(curr.orien))/tan(delta);
			next.y = curr.y + L*(cos(curr.orien) - cos(next.orien))/tan(delta);
		}
		else{
			next.x = curr.x + velocity*cos(curr.orien)*t;
			next.y = curr.y + velocity*sin(curr.orien)*t;
		}

		return next;
	}


	void genSuccessorsBicycle(Node& curr, std::vector<Node>& successors){
		successors.clear();

		for(int i = 0;i < deltaAction.size();i++){
			Node succ = executeAction(curr,deltaAction[i],t);
			bool val = CollisionCheckRobot(succ);

			succ.g = curr.g + t + std::fabs(deltaAction[i]);
			succ.f = succ.g + calHeuristic(succ);
			succ.ind = treeData.size();
			succ.parent = curr.ind;

			if(!val){
				treeData.push_back(succ);
				successors.push_back(succ);
			}
		}
	}

	void getPath(Node& node, std::vector<Node>& path){
		path.clear();

		Node curr = node;
		while(curr.ind > 0){
			path.push_back(curr); 
			curr = treeData[curr.parent];
		}
	}

	void dispPt(cv::Mat& img, Node n, uint rad, uint val){
		cv::circle(img,cv::Point(n.x/0.0275,n.y/0.0275),rad,val,-1);
	}

	bool genTrajectory(Node st, Node gl, std::vector<Node>& path){
		st.x *= 0.0275;
		st.y *= 0.0275;
		gl.x *= 0.0275;
		gl.y *= 0.0275;

		goalDest = gl;
		float cost = 0;
		Node prev = gl;

		if(CollisionCheckRobot(st)){
			std::cout<<"Invalid start"<<std::endl;
			return false;
		}
		else
			std::cout<<"Feasible start"<<std::endl;


		if(CollisionCheckRobot(gl)){
			std::cout<<"Invalid goal"<<std::endl;
			return false;
		}
		else
			std::cout<<"Feasible goal"<<std::endl;

		cv::Mat img = map.clone();
		dispPt(img,st,5,255);
		dispPt(img,gl,5,255);

		Queue queOpen;
		Dictionary dictOpen(map.rows, map.cols);
		Dictionary dictClosed(map.rows, map.cols);

		bool solution = false;
		Node start = st;
		Node goal = gl;
		start.g = 0;
		start.f = calHeuristic(start);
		start.ind = treeData.size();
		start.parent = -1; 
		treeData.push_back(start);

		queOpen.push(start);
		dictOpen.add(start);

		std::vector<Node> nodeCurrSuccessors;
		Node nodeCurr;

		bool visualize = false;
		// std::cout<<"Astarv2.h"<<std::endl;
		while(queOpen.length()){
			nodeCurr = queOpen.pop();
			// std::cout<<"Curr : "<<nodeCurr.x<<','<<nodeCurr.y<<std::endl;
			dictOpen.remove(nodeCurr);

			if(visualize){
				dispPt(img,nodeCurr,3,155);
				cv::circle(img,cv::Point(nodeCurr.x/0.0275,nodeCurr.y/0.0275),3,155,-1);
				cv::imshow("image",img);
				uint key = cv::waitKey(1);
				if(key == 27)
					break;
				if(key == 32)
					cv::waitKey(0);				
			}

			if(Distance(nodeCurr,goal) < goal_threshold){
				solution = true;
				getPath(nodeCurr,path);
				break;
			}

			dictClosed.add(nodeCurr);
			// genSuccessors(nodeCurr,goal,nodeCurrSuccessors);
			genSuccessorsBicycle(nodeCurr,nodeCurrSuccessors);
			for(int i = 0;i < nodeCurrSuccessors.size();i++){
				Node nodeSucc = nodeCurrSuccessors[i];
				bool valOpen = dictOpen.isAvailable(nodeSucc);
				bool valClosed = dictClosed.isAvailable(nodeSucc);

				// std::cout<<"Succ : "<<nodeSucc.x<<','<<nodeSucc.y<<','<<nodeSucc.orien*180/PI<<','<<nodeSucc.g<<','<<nodeSucc.f<<std::endl;
				// std::cout<<"Open : "<<valOpen<<std::endl;
				// std::cout<<"Closed : "<<valClosed<<std::endl;

				if(!valClosed){
					if(!valOpen){
						queOpen.push(nodeSucc);
						dictOpen.add(nodeSucc);
					}
					else{
						int openSuccInd = dictOpen.get(nodeSucc);

						Node& openSucc = treeData[openSuccInd];
						if(nodeSucc.g < openSucc.g){
							queOpen.push(nodeSucc);
							dictOpen.add(nodeSucc);
						}
					}
				}
			}

			// std::cout<<"--------------------------"<<std::endl;
		}

		std::cout<<"Total Nodes : "<<treeData.size()<<std::endl;

		return solution;
	}
};




		// std::cout<<"1"<<std::endl;
		// std::cout<<"2"<<std::endl;
		// std::cout<<"3"<<std::endl;
		// std::cout<<"4"<<std::endl;
		// std::cout<<"5"<<std::endl;
		// std::cout<<"6"<<std::endl;
		// std::cout<<"7"<<std::endl;
		// std::cout<<"8"<<std::endl;
		// std::cout<<"9"<<std::endl;
		// std::cout<<"10"<<std::endl;


// write a heuristic function using the each action state.
		// std::cout<<"4"<<std::endl;
		// std::cout<<"A*"<<std::endl;
		// std::cout<<"--------------------"<<std::endl;
		// std::cout<<"T1 : "<<t1*1000<<", T1 avg : "<<t1*1000/n1<<", N : "<<n1<<std::endl;
		// std::cout<<"T2 : "<<t2*1000<<", T2 avg : "<<t2*1000/n2<<", N : "<<n2<<std::endl;
		// std::cout<<"T3 : "<<t3*1000<<", T3 avg : "<<t3*1000/n3<<", N : "<<n3<<std::endl;
		// std::cout<<"T4 : "<<t4*1000<<", T4 avg : "<<t4*1000/n4<<", N : "<<n4<<std::endl;
		// std::cout<<"-----"<<std::endl;
		// std::cout<<"T5 : "<<t5*1000<<", T5 avg : "<<t5*1000/n5<<", N : "<<n5<<std::endl;
		// std::cout<<" T6 : "<<t6*1000<<", T6 avg : "<<t6*1000/n6<<", N : "<<n6<<std::endl;
		// std::cout<<" T7 : "<<t7*1000<<", T7 avg : "<<t7*1000/n7<<", N : "<<n7<<std::endl;
		// std::cout<<" T8 : "<<t8*1000<<", T8 avg : "<<t8*1000/n8<<", N : "<<n8<<std::endl;
		// std::cout<<" T9 : "<<t9*1000<<", T9 avg : "<<t9*1000/n9<<", N : "<<n9<<std::endl;
		// std::cout<<" T10 : "<<t1*1000<<"T10 avg : "<<t10*1000/n10<<", N : "<<n10<<std::endl;;
		// std::cout<<"-----"<<std::endl;
		// // std::cout<<"Open List Size : "<<dictOpen.size()<<std::endl;
		// // std::cout<<"Closed List Size : "<<dictClosed.size()<<std::endl;
		// std::cout<<"--------------------"<<std::endl;
		// std::cout<<"--------------------"<<std::endl;
		// std::cout<<"3"<<std::endl;
		// to1 = clock();
		// std::cout<<"4"<<std::endl;
		// to2 = clock();
		// std::cout<<"Open : "<<float(to2-to1)/CLOCKS_PER_SEC <<std::endl;
		// std::cout<<"5"<<std::endl;
		// std::cout<<"Closed : "<<float(tc2-tc1)/CLOCKS_PER_SEC <<std::endl;
		// std::cout<<"6"<<std::endl;
		// float t1=0,t2=0,t3=0,t4=0,t5=0,t6=0,t7=0,t8=0,t9=0,t10=0;
		// int n1=0,n2=0,n3=0,n4=0,n5=0,n6=0,n7=0,n8=0,n9=0,n10=0;
		// clock_t t11,t12;
		// t11 = clock();
		// t12 = clock();
		// t1 += float(t12-t11)/CLOCKS_PER_SEC;
		// n1++;
		// clock_t t21,t22;
		// t21 = clock();
		// t22 = clock();
		// t2 += float(t22-t21)/CLOCKS_PER_SEC;
		// n2++;
		// clock_t t31,t32;
		// t31 = clock();
		// t32 = clock();
		// t3 += float(t32-t31)/CLOCKS_PER_SEC;
		// n3++;
		// clock_t t41,t42;
		// t41 = clock();
		// t42 = clock();
		// t4 += float(t42-t41)/CLOCKS_PER_SEC;
		// n4++;
		// clock_t t51,t52;
		// t51 = clock();
		// t52 = clock();
		// t5 += float(t52-t51)/CLOCKS_PER_SEC;
		// n5++;
		// clock_t t61,t62;
		// t61 = clock();
		// t62 = clock();
		// t6 += float(t62-t61)/CLOCKS_PER_SEC;
		// n6++;
		// clock_t t71,t72;
		// t71 = clock();
		// t72 = clock();
		// t7 += float(t72-t71)/CLOCKS_PER_SEC;
		// n7++;
		// clock_t t81,t82;
		// t81 = clock();
		// t82 = clock();
		// t8 += float(t82-t81)/CLOCKS_PER_SEC;
		// n8++;
		// clock_t t91,t92;
		// t91 = clock();
		// t92 = clock();
		// t9 += float(t92-t91)/CLOCKS_PER_SEC;
		// n9++;
		// clock_t t101,t102;
		// t101 = clock();
		// t102 = clock();
		// t10 += float(t102-t101)/CLOCKS_PER_SEC;
		// n10++;


#endif