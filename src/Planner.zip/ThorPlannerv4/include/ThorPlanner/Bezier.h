#include <iostream>
#include <vector>
#include "Data.h"
#include "IndicesDivider.h"


typedef unsigned long long int ullint;

class BezierFit{
public:
	BezierFit(){}

	ullint fact(int a){
		if(a < 0)
			throw std::invalid_argument("ERROR, a < 0");

		if(a == 0)
			return 1;
		else{
			ullint val = a;
			for(int i = a-1;i > 0;i--)
				val *= i;

			return val;
		}

	}

	ullint nCa(int n, int a){
		if(a > n)
			throw std::invalid_argument("ERROR, a > n");
		else{
			return fact(n)/(fact(n-a)*fact(a));
		}
	}

	void bezierCurveFit(std::vector<Node>& pts, std::vector<Node>& pts_fit){
		pts_fit.clear();
		for(float i = 0;i <= pts.size()-1;i++){
			float t = i/float(pts.size()-1);

			double x = 0,y = 0;
			for(int j = 0;j < pts.size();j++){
				x = x + nCa(pts.size()-1,j)*pow(1-t, pts.size()-j-1)*pow(t,j)*pts[j].x;
				y = y + nCa(pts.size()-1,j)*pow(1-t, pts.size()-j-1)*pow(t,j)*pts[j].y;
			}

			Node pt = pts[i];
			pt.x = x;
			pt.y = y;
			pts_fit.push_back(pt);
		}

	}

	void bezierCurveFit1(std::vector<Node>& pts, std::vector<Node>& pts_fit){
		pts_fit.clear();
		uint n = pts.size()-1;
		for(float i = 0;i <= n;i++){
			float t = i/float(n);

			double x = 0,y = 0;
			std::pair<double, double> orien;
			for(int j = 0;j < pts.size();j++){
				ullint ncj = nCa(n,j);
				std::cout<<"ncj : "<<ncj<<std::endl;
				std::cout<<"n : "<<n<<std::endl;
				std::cout<<"re : "<<(n-j)/float(n)<<std::endl;

				//its throwing problem when there is only one point in the list.

				ullint n_1cj = ncj*(n-j)/n;
				x = x + ncj*pow(1-t, n-j)*pow(t,j)*pts[j].x;
				y = y + ncj*pow(1-t, n-j)*pow(t,j)*pts[j].y;

				if(j < n){
					orien.first = n_1cj*pow(t,j)*pow(1-t, n-j-1)*n*(pts[j+1].x - pts[j].x);
					orien.second = n_1cj*pow(t,j)*pow(1-t, n-j-1)*n*(pts[j+1].y - pts[j].y);
				}

			}

			Node pt = pts[i];
			pt.x = x;
			pt.y = y;
			if(i < n){
				pt.orien = atan2(orien.second, orien.first);
				pt.orien = (inRo(pt.orien*180/PI)%360)*PI/180;
			}

			pts_fit.push_back(pt);
		}

	}


};
