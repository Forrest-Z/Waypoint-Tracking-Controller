#include <iostream>
#include "Data.h"




namespace ThorPlanner{


	class TF{
		std::string mapAddress;
		float mapRes;
		bool negate;
		float occThresh ;
		float freeThresh;
		float originX, originY, originO;

		cv::Mat map, mapRaw;;
		uint mapRows, mapCols;
	public:
		TF(){}

		~TF(){
			std::cout<<"===================================="<<std::endl;

			map.release();
			mapRaw.release();

			delete &map;
			delete &mapRaw;

			std::cout<<"++++++++++++++++++++++++++++++++++++"<<std::endl;
			// std::cout<<"map : "<<this->map.rows<<','<<this->map.cols<<std::endl;
			// std::cout<<"mapRaw : "<<this->mapRaw.rows<<','<<this->mapRaw.cols<<std::endl;
		}

		void initialise(){
			mapAddress = MapData::MapAddress;
			mapRes = MapData::MapRes;
			negate = MapData::Negate;
			occThresh  = MapData::OccupiedThresh;
			freeThresh = MapData::FreeThresh;

			getOrigin();

			mapRaw = cv::imread(mapAddress,0);

			mapRows = mapRaw.rows;
			mapCols = mapRaw.cols;

			if(mapRows == 0 || mapCols == 0)
				throw std::invalid_argument("ERROR, TF class, Map Address invalid");


			map = cv::Mat::zeros(cv::Size(mapCols, mapRows), CV_8UC1);

			for(int i = 0;i < mapRows;i++){
				for(int j = 0;j < mapCols;j++){
					float p;
					if(!negate)
						p = (255 - uint(mapRaw.at<uchar>(i,j)))/255.0;
					else
						p = uint(mapRaw.at<uchar>(i,j))/255.0;

					if(p < freeThresh)
						map.at<uchar>(i,j) = 0;
					else
						map.at<uchar>(i,j) = 255;
				}
			}		
		}

		void getOrigin(){
			originX = -MapData::OriginX*cos(MapData::OriginOrien) - MapData::OriginY*sin(MapData::OriginOrien);
			originY = -MapData::OriginX*(-sin(MapData::OriginOrien)) - MapData::OriginY*cos(MapData::OriginOrien);
			originO = -MapData::OriginOrien;
		}

		void getMap(cv::Mat& map){
			kernel_size = 3;
        	cv::Mat kernel = cv::Mat::ones( kernel_size, kernel_size, CV_32F )/ (float)(kernel_size*kernel_size);
			cv::Mat opening_img = cv::morphologyEx(map, cv::MORPH_OPEN, kernel);
			map = this->opening_img.clone();
			// cv::imshow("Map",map);
			// cv::waitKey(0);
			// cv::destroyAllWindows();
		}

		void NodeTOmap(Node pt, Node& ptShift){
			Node ptMapBotOrigin(pt.x*mapRes, (mapRows - pt.y)*mapRes,-pt.orien);
			ptShift.x = (ptMapBotOrigin.x - originX)*cos(originO) + (ptMapBotOrigin.y - originY)*sin(originO);
			ptShift.y = -(ptMapBotOrigin.x - originX)*sin(originO) + (ptMapBotOrigin.y - originY)*cos(originO);
			ptShift.orien = ptMapBotOrigin.orien - originO;
		}

		void mapTONode(Node pt, Node& ptShift){
			Node ptMapBotOrigin;
			ptMapBotOrigin.x = pt.x*cos(-originO) + pt.y*sin(-originO) + originX;
			ptMapBotOrigin.y = -pt.x*sin(-originO) + pt.y*cos(-originO) + originY;

			std::cout<<"Pt Map : "<<ptMapBotOrigin.x<<','<<ptMapBotOrigin.y<<std::endl;

			ptShift.x =	ptMapBotOrigin.x/mapRes;
			ptShift.y = mapRows - ptMapBotOrigin.y/mapRes;
			ptShift.orien = pt.orien + originO;
			ptShift.orien *= -1;
		}

		void shiftNodesToMap(std::vector<Node>& pts, std::vector<Node>& shiftedPts){
			shiftedPts.clear();

			for(Node pt : pts){
				Node shiftPt;
				pt.x /= mapRes;
				pt.y /= mapRes;
				NodeTOmap(pt, shiftPt);

				shiftedPts.push_back(shiftPt);
			}

		}

		void shiftNodesToMapMsg(std::vector<Node>& pts, nav_msgs::Path& pathMsg){
			std::vector<geometry_msgs::PoseStamped> shiftPts;

			for(Node pt : pts){
				Node shiftPt;
				pt.x /= mapRes;
				pt.y /= mapRes;
				NodeTOmap(pt, shiftPt);

				geometry_msgs::PoseStamped shiftPtMsg;
				shiftPtMsg.header.stamp = ros::Time::now();
				shiftPtMsg.header.frame_id = "map";
				shiftPtMsg.header.seq = pt.velocity < 0 ? 0 : 1;		// 0 for backward, 1 for forward, used when local planner is subscribing to nav_msgs::Path

				shiftPtMsg.pose.position.x = shiftPt.x;
				shiftPtMsg.pose.position.y = shiftPt.y;
				shiftPtMsg.pose.position.z = 0;
		// sending the velocity through the z coordinate.

				tf2::Quaternion quat;
				quat.setRPY(0, 0, shiftPt.orien);
				shiftPtMsg.pose.orientation = tf2::toMsg(quat);

				shiftPts.push_back(shiftPtMsg);
			}

			pathMsg.header.frame_id = "map";
			pathMsg.header.stamp = ros::Time::now();
			pathMsg.poses = shiftPts;
		}

		Node shiftFrontToBack(Node n){
			Node nShifted;
			nShifted = n;
			nShifted.x = nShifted.x - VehicleData::Length*cos(n.orien)/mapRes;
			nShifted.y = nShifted.y - VehicleData::Length*sin(n.orien)/mapRes;

			return nShifted;
		}

		Node shiftBackToFront(Node n){
			Node nShifted;
			nShifted = n;
			nShifted.x = nShifted.x + VehicleData::Length*cos(n.orien)/mapRes;
			nShifted.y = nShifted.y + VehicleData::Length*sin(n.orien)/mapRes;

			return nShifted;
		}

		FluxMsgs::Node NodeToNodeMsg(Node n){
			FluxMsgs::Node nMsg;
			nMsg.x = n.x;
			nMsg.y = n.y;
			nMsg.z = n.z;
			nMsg.orien = n.orien;
			nMsg.g = n.g;
			nMsg.f = n.f;
			nMsg.ind = n.ind;
			nMsg.parent = n.parent;
			nMsg.delta = n.delta;
			nMsg.velocity = n.velocity;
			nMsg.velConstraint = n.velConstraint;
			nMsg.time = n.time;

			return nMsg;
		}

		Node NodeMsgToNode(FluxMsgs::Node nMsg){
			Node n;
			n.x = nMsg.x;
			n.y = nMsg.y;
			n.z = nMsg.z;
			n.orien = nMsg.orien;
			n.g = nMsg.g;
			n.f = nMsg.f;
			n.ind = nMsg.ind;
			n.parent = nMsg.parent;
			n.delta = nMsg.delta;
			n.velocity = nMsg.velocity;
			n.velConstraint = nMsg.velConstraint;
			n.time = nMsg.time;

			return n;
		}

		void shiftNodesToNodeArrayMsg(std::vector<Node>& pts, FluxMsgs::NodeArray& pathMsg){
			pathMsg.path.clear();
			std::vector<geometry_msgs::PoseStamped> shiftPts;

			for(Node pt : pts){
				Node shiftPt;
				pt.x /= mapRes;
				pt.y /= mapRes;
				shiftPt = pt;
				NodeTOmap(pt, shiftPt);

				pathMsg.path.push_back(NodeToNodeMsg(shiftPt));
			}

		}

	};

}


