#ifndef OBSCOSTMAPH
#define OBSCOSTMAPH

#include <iostream>
#include "Data.h"
#include "kdtree.h"

class ObsCostMap{
	cv::Mat& map;
	std::vector<KDT::MyPoint> kdt_pts;
	std::vector<cv::Point> bound_pts;
	KDT::KDTree<KDT::MyPoint> kdt;

public:
	ObsCostMap(cv::Mat& map_) : map(map_){
		getBoundPts();
		buildKDT();
	}

	void getBoundPts(){
		bound_pts.clear();
		cv::Mat imgEr;
		// cv::erode(map, imgEr, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3)));
		cv::Mat img_bound = map;
		cv::findNonZero(img_bound,bound_pts);
	}

	void buildKDT(){
		kdt_pts.clear();
		for(int i = 0;i < bound_pts.size();i++)
			kdt_pts.push_back(KDT::MyPoint(bound_pts[i].x, bound_pts[i].y));

		kdt.build(kdt_pts);
	}

	int indSearch(Node& pt){
		return kdt.nnSearch(KDT::MyPoint(pt.x, pt.y));
	}

	Node getNearPt(Node& pt){
		uint ind = indSearch(pt);
		return Node(bound_pts[ind].x,bound_pts[ind].y,0);
	}

	// float maxMat(Eigen::MatrixXf mat){
	float maxMat(Eigen::MatrixXf& matCosts){
		float maxi = -100000000000000;

		for(int i = 0;i < matCosts.rows();i++){
			for(int j = 0;j < matCosts.cols();j++){
				if(matCosts(i,j) > maxi && matCosts(i,j) < 1000000000)
					maxi = matCosts(i,j);
			}
		}

		return maxi;
	}

	void dispCosts(Eigen::MatrixXf& matCosts){
		cv::Mat img = cv::Mat::zeros(matCosts.rows(),matCosts.cols(),CV_8UC1);
		float maxVal = maxMat(matCosts);

		for(int i = 0;i < matCosts.rows();i++){
			for(int j = 0;j < matCosts.cols();j++){
				if(matCosts(i,j) < 10000)
					img.at<uchar>(i,j) = matCosts(i,j)*255/maxVal;
			}
		}

		cv::imshow("ObsCostMap",img);
		cv::waitKey(0);
		cv::destroyAllWindows();

	}

	void genCostMap(Eigen::MatrixXf& mat_costs){
		if(mat_costs.cols() != map.cols || mat_costs.rows() != map.rows)
			throw std::invalid_argument("ERROR, ObsCostMap.h, matrix and map sizes are not same");

		for(int i = 0;i < map.rows;i++){
			for(int j = 0;j < map.cols;j++){
				if(map.at<uchar>(i,j) < 50){
					Node n(j,i,0);
					Node nearPt = getNearPt(n);
					mat_costs(i,j) = 1/(Distance(n,nearPt)*MapData::MapRes);
				}
			}
		}
	}

};

#endif