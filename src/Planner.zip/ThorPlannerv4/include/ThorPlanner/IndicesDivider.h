#ifndef INDICESDIVIDERH
#define INDICESDIVIDERH

#include <iostream>




class IndicesDivider{
	int n_total, n_req, distBetPts, remainder;
	float fraction;
	int i_curr = 0;
	std::vector<int> index_table;

public:
	IndicesDivider(int n_total_, int n_req_) : n_total(n_total_), n_req(n_req_){
		distBetPts = n_total/(n_req-1);
		remainder = n_total%(n_req-1);
		fraction = float(remainder)/(n_req-1);

		if(n_req > n_total){
			std::cout<<"Required Points : "<<n_req<<", "<<"Available Points : "<<n_total<<std::endl;
			throw std::invalid_argument("ERROR, the required Waypoints are more than the available Waypoints");
		}

		genIndexTable();
	}

	void genIndexTable(){
		int ind = 0;
		float ws = 0;
		int extra = 0;

		index_table.push_back(ind);
		for(int i = 1;i < n_req;i++){
			if(ws > 1){
				extra = 1;
				ws = ws - 1;
			}

			ind = ind + distBetPts + extra;
			if(extra == 1)
				extra = 0;

			if(i == n_req - 1)
				ind = n_total-1;

			ws += fraction;

			if(ind >= n_total)
				std::invalid_argument("ERROR, index generated beyond the size");

			index_table.push_back(ind);
		}

	}


	int getIndex(){
		if(i_curr >= n_req){
			std::cout<<"ERROR, the index has reached maximum, can't return more indices"<<std::endl;
		}
		else{
			int ind_ret = index_table[i_curr];
			i_curr++;
			return ind_ret;
		}

	}

	void genIndices(std::vector<int>& indices){
		indices.clear();
		indices = index_table;
	}

};




#endif