#ifndef FUNCH
#define FUNCH

#include <iostream>
#include <queue>
#include <cmath>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "Eigen/Dense"
#include <bitset>
#include "Data.h"
#include <unordered_map>


#define PI 3.141592653589793238


int inRo(float val){
	return int(round(val));
}


class IndexMat{
public:
	int indX = -1;
	int indY = -1;
	int indOrien = -1;

	IndexMat(){}
	IndexMat(int indx_,int indy_,int indo_) : indX(indx_),indY(indy_),indOrien(indo_){}
};


float Distance(Node& n1, Node& n2){
	return sqrt(pow(n1.x - n2.x,2) + pow(n1.y - n2.y,2));
}

void dispPt(cv::Mat& img, Node n, uint rad, uint val){
	cv::circle(img,cv::Point(n.x/MapData::MapRes,n.y/MapData::MapRes),rad,val,-1);
}


bool operator <=(const Node& Node1, const Node& Node2)
	{return Node1.f <= Node2.f;}

bool operator <(const Node& Node1, const Node& Node2)
	{return Node1.f < Node2.f;}

bool operator ==(const Node& Node1, const Node& Node2)
	{return Node1.x == Node2.x && Node1.y == Node2.y && (inRo(Node1.orien*180/PI) == inRo(Node2.orien*180/PI));}

bool operator >=(const Node& Node1, const Node& Node2)
	{return Node1.f >= Node2.f;}

bool operator >(const Node& Node1, const Node& Node2)
	{return Node1.f > Node2.f;}


void dispPath(cv::Mat& img, std::vector<Node>& path){
	for(int i = 0;i < path.size();i++)
		img.at<uchar>(path[i].y,path[i].x) = 255;
}

std::string HashFunc(const Node& node){
	std::string locX = std::to_string(inRo(node.x/MapData::MapRes));
	std::string locY = std::to_string(inRo(node.y/MapData::MapRes));
	std::string locT = std::to_string(inRo(node.orien*180/PI));
	std::string str_arg = locX + locY + locT;

	return str_arg;
}

class Queue{
public:
	std::priority_queue<Node,std::vector<Node>,std::greater<Node>> que;

	void push(Node& node){
		this->que.push(node);}

	Node pop(){
		if(this->length() > 0){
			Node node = que.top();
			this->que.pop();
			return node;
		}
		else
			throw std::invalid_argument("ERROR, Queue is empty.");

	}

	int length(){
		return this->que.size();}
};

class Dictionary{
	std::unordered_map<std::string,int> dictionary;

	typedef Eigen::Matrix<std::bitset<AstarData::OrientationSize>,Eigen::Dynamic,Eigen::Dynamic> mapMat;
	mapMat occupancyMat;

public:
	Dictionary(uint height, uint width){
		occupancyMat.resize(height, width);
	}

	IndexMat genNodeIndex(Node& n){
		if(n.x < 0 || n.y < 0 || n.x >= occupancyMat.cols()*MapData::MapRes || n.y >= occupancyMat.rows()*MapData::MapRes)
			return IndexMat(-100,-100,-100);

		int indx = inRo(n.x/MapData::MapRes);
		int indy = inRo(n.y/MapData::MapRes);
		int orien = inRo(n.orien*180/PI);
		orien = orien%360;
		int indo = orien/(AstarData::ActionAngResForward*180/PI);

		return IndexMat(indx,indy,indo);
	}

	void add(Node& node){
		this->dictionary[HashFunc(node)] = node.ind;

		IndexMat ind_node = genNodeIndex(node);
		if(ind_node.indX >= 0)
			occupancyMat(ind_node.indY,ind_node.indX)[ind_node.indOrien] = true;
	}

	void remove(Node& node){
		this->dictionary.erase(HashFunc(node));

		IndexMat ind_node = genNodeIndex(node);
		if(ind_node.indX >= 0)
			occupancyMat(ind_node.indY,ind_node.indX)[ind_node.indOrien] = false;
	}

	int size(){
		return this->dictionary.size();
	}

	int get(Node& node){

		if(this->isAvailable(node))
			return this->dictionary[HashFunc(node)];
		else
			throw std::invalid_argument("ERROR, no Key in the Dictionary with given input.");
	}

	bool isAvailable(Node& n){

		IndexMat ind_node = genNodeIndex(n);
		if(ind_node.indX >= 0)
			return occupancyMat(ind_node.indY,ind_node.indX)[ind_node.indOrien];
		else
			return false;
	}

};

		// std::cout<<"Node : "<<n.x/MapData::MapRes<<','<<n.y/MapData::MapRes<<std::endl;
		// std::cout<<"adds"<<std::endl;
		// std::cout<<"removes"<<std::endl;
		// std::cout<<"adde"<<std::endl;
		// std::cout<<"removee"<<std::endl;
		// std::cout<<"gets"<<std::endl;
		// std::cout<<"gete"<<std::endl;
		// std::cout<<"avails"<<std::endl;
		// std::cout<<"availe"<<std::endl;

Node inRo(Node n){
	return Node(inRo(n.x), inRo(n.y), inRo(n.orien*180/PI)*PI/180);
}

class AstarAction{
public:
	float delta;
	float velocity;
	std::vector<Node> boundaryPts;
	float cost;

	AstarAction(float delta_, float velocity_, float t_, std::vector<Node> boundPts) : delta(delta_), cost(t_), boundaryPts(boundPts), velocity(velocity_){}
};


#endif