#ifndef PUREPURSUITH
#define PUREPURSUITH
#include <iostream>
// #include "Functions.h"
#include "kdtree.h"
#include "Data.h"


class PurePursuit{
	float L = VehicleData::Length;
	float deltaMax = VehicleData::DeltaMax;
	float deltaMin = VehicleData::DeltaMin;
	float deltaDot = VehicleData::DeltaDot;
	float PUREPURSUITEXITOFFSET = PurePursuitData::ExitOffset;
	int LOOKAHEADIND = PurePursuitData::LookAheadIndex;
	float timeStep = PurePursuitData::TimeStep;

	Node start;
	std::vector<Node> path;
	KDT::KDTree<KDT::MyPoint> kdtree;

public:
	PurePursuit(){};
	PurePursuit(Node start_,std::vector<Node>& path_) : start(start_),path(path_){
		std::vector<KDT::MyPoint> pathTree(path.size());
		for(int i = 0;i < path.size();i++)
			pathTree[i] = KDT::MyPoint(path[i].x,path[i].y);

		kdtree.build(pathTree);
	}

	void Transformation(Node& origin, Node& n, Node& nT){
		nT.x = (n.x - origin.x)*cos(origin.orien) + (n.y - origin.y)*sin(origin.orien);
		nT.y = -(n.x - origin.x)*sin(origin.orien) + (n.y - origin.y)*cos(origin.orien);
		nT.z = n.z;
	}

	float calEta(Node& curr, Node& lkPt){
		Node lkPt_transf;
		Transformation(curr,lkPt,lkPt_transf);

		return -atan2(lkPt_transf.y,lkPt_transf.x);
	}

	float calDeltaForward(Node& curr, Node& lkPt){			//change the formula
		float eta = calEta(curr,lkPt);
		float delta;

		if(fabs(eta) > PI/2)
			delta = eta < 0 ? deltaMax : deltaMin;
		else
			delta = -atan(2*L*sin(eta)/Distance(curr,lkPt));

		if(delta > deltaMax)
			delta = deltaMax;
		if(delta < deltaMin)
			delta = deltaMin;

		return delta;
	}

	float calDeltaReverse(Node& curr, Node& lkPt){			//change the formula
		float eta = calEta(curr,lkPt);

		if(eta != 0)
			eta = (PI - fabs(eta))*eta/fabs(eta);

		float delta;
		if(fabs(eta) > PI/2)
			delta = eta < 0 ? deltaMax : deltaMin;
		else
			delta = -atan(2*L*sin(eta)/Distance(curr,lkPt));

		if(delta > deltaMax)
			delta = deltaMax;
		if(delta < deltaMin)
			delta = deltaMin;

		return delta;
	}

	float calDelta(Node& curr, Node& lkPt){
		if(curr.velocity >= 0)
			return calDeltaForward(curr, lkPt);
		else
			return calDeltaReverse(curr, lkPt);
	}

	int getNearPt(Node& curr){
		KDT::MyPoint queryPt(curr.x,curr.y);
		int ind = kdtree.nnSearch(queryPt);

		return ind;
	}

	int getFollowInd(Node& curr, std::vector<Node>& path){
		int ind = getNearPt(curr);
		int pathSize = path.size();

		return std::min(pathSize-1,ind + LOOKAHEADIND);
	}

	void executeAction(Node& curr, float delta, float t, Node& next){
		float x,y,z,orien,deltaOut;

		if(delta > deltaMax)
			delta = deltaMax;
		if(delta < deltaMin)
			delta = deltaMin;

		orien = curr.orien + curr.velocity*tan(curr.delta)*t/L;
		if(curr.delta*180/PI != 0){
			x = curr.x + L*(sin(orien) - sin(curr.orien))/tan(curr.delta);
			y = curr.y + L*(cos(curr.orien) - cos(orien))/tan(curr.delta);
		}
		else{
			x = curr.x + curr.velocity*cos(orien)*t;
			y = curr.y + curr.velocity*sin(orien)*t;
		}
		z = curr.z;
		delta == curr.delta ? deltaOut = curr.delta : deltaOut = curr.delta + deltaDot*t*(delta - curr.delta)/std::fabs(delta - curr.delta);

		next.x = x;
		next.y = y;
		next.z = z;
		next.orien = orien;
		next.delta = deltaOut;
		next.velocity = curr.velocity;
	}

	void genPursuit(std::vector<Node>& pursuit_path){
		Node curr = start;
		Node next;
		float dist_goal_prev;
		float dist_goal_curr;
		while(true){
			pursuit_path.push_back(curr);
			dist_goal_curr = Distance(curr,path[path.size()-1]);

			if(dist_goal_curr < PUREPURSUITEXITOFFSET){
				if(dist_goal_curr > dist_goal_prev)
					break;
			}

			int ind_follow = getFollowInd(curr,path);
			float delta_action = calDelta(curr,path[ind_follow]);
			executeAction(curr,delta_action,timeStep,next);
			curr = next;

			dist_goal_prev = dist_goal_curr;
		}
	}	
};




		// cv::Mat img = cv::Mat::zeros(500,500,CV_8UC1);
		// dispPath(img,path);

			// cv::circle(img,cv::Point(curr.x,curr.y),1,255,-1);
			// std::cout<<"Curr : "<<curr.x<<','<<curr.y<<std::endl;
			// cv::Mat imgCp = img.clone();
			// cv::circle(imgCp,cv::Point(path[ind_follow].x,path[ind_follow].y),3,155,-1);
			// std::cout<<"Delta : "<<delta_action*180/PI<<std::endl;
			// cv::imshow("image",imgCp);
			// cv::waitKey(1);
		// cv::waitKey(0);
			// std::cout<<"1"<<std::endl;
			// std::cout<<"2"<<std::endl;
			// std::cout<<"3"<<std::endl;
			// std::cout<<"4"<<std::endl;
			// std::cout<<"5"<<std::endl;
			// std::cout<<"6"<<std::endl;
			// std::cout<<"Pure Pursuit"<<std::endl;
			// std::cout<<"--------------------"<<std::endl;
			// std::cout<<"T1 : "<<t1<<std::endl;
			// std::cout<<"T2 : "<<t2<<std::endl;
			// std::cout<<"T3 : "<<t3<<std::endl;
			// std::cout<<"--------------------"<<std::endl;
			// std::cout<<"--------------------"<<std::endl;
			// std::cout<<"-----------------------"<<std::endl;
			// std::cout<<"Curr Loc : "<<curr.x<<','<<curr.y<<','<<curr.orien*180/PI<<','<<curr.delta*180/PI<<','<<curr.velocity<<std::endl;
			// clock_t t11,t12;
			// t11 = clock();
			// t12 = clock();
			// t1 += float(t12-t11)/CLOCKS_PER_SEC;
			// n1++;
			// std::cout<<"Index : "<<ind_follow<<std::endl;
			// std::cout<<"Follow Pt : "<<path[ind_follow].x<<','<<path[ind_follow].y<<','<<path[ind_follow].orien*180/PI<<std::endl;
			// clock_t t21,t22;
			// t21 = clock();
			// t22 = clock();
			// t2 += float(t22-t21)/CLOCKS_PER_SEC;
			// n2++;
			// std::cout<<"Delta Req : "<<delta_action*180/PI<<std::endl;
			// clock_t t31,t32;
			// t31 = clock();
			// t32 = clock();
			// t3 += float(t32-t31)/CLOCKS_PER_SEC;
			// n3++;
			// std::cout<<"Delta Curr : "<<next.delta*180/PI<<std::endl;
			// std::cout<<"New Loc : "<<next.x<<','<<next.y<<','<<next.orien*180/PI<<','<<next.delta*180/PI<<','<<next.velocity<<std::endl;
			// std::cout<<"-----------------------"<<std::endl;
			// cv::circle(img,cv::Point(curr.x,curr.y),1,255,-1);
			// cv::circle(imgDisp,cv::Point(path[ind_follow].x,path[ind_follow].y),5,255,-1);
			// cv::imshow("image",imgDisp);
			// cv::waitKey(0);
			// std::cout<<"Path Size : "<<path.size()<<std::endl;
			// clock_t t41,t42;
			// t41 = clock();
			// t42 = clock();
			// t4 += float(t42-t41)/CLOCKS_PER_SEC;
			// n4++;
			// clock_t t51,t52;
			// t51 = clock();
			// clock_t t61,t62;
			// t61 = clock();
			// t62 = clock();
			// t6 += float(t62-t61)/CLOCKS_PER_SEC;
			// n6++;
			// clock_t t71,t72;
			// t71 = clock();
			// t72 = clock();
			// t7 += float(t72-t71)/CLOCKS_PER_SEC;
			// n7++;

#endif