#ifndef GRASSFIRE_HPP
#define GRASSFIRE_HPP
#include <iostream>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "Eigen/Dense"
#include "Data.h"

class GrassFire{
public:
	cv::Mat img;
	Node goal;

	GrassFire(cv::Mat& img, Node& goal){
		this->img = img.clone();
		this->goal = goal;
	}

	std::vector<Node> genNeigh(Node& pt){
		std::vector<Node> neighGlob;
		int xMin = 0;
		int xMax = img.cols;
		int yMin = 0;
		int yMax = img.rows;

		for(int i = -1;i <= 1;i++){
			for(int j = -1;j <= 1;j++){
				if(!(i == 0 && j == 0)){
					Node neighPt(pt.x + i,pt.y + j, 0);

					if(neighPt.x >= xMin && neighPt.x < xMax && neighPt.y >= yMin && neighPt.y < yMax && img.at<uchar>(neighPt.y,neighPt.x) < 50){
						neighPt.g = Distance(pt,neighPt)*MapData::MapRes;
						neighGlob.push_back(neighPt);
					}
				}
			}
		}

		return neighGlob;
	}

	Node minInd(Eigen::MatrixXf pts){
		float minVal = std::numeric_limits<float>::infinity();
		Node ind;

		for(int i = 0;i < pts.cols();i++){
			for(int j = 0;j < pts.rows();j++){
				if(pts(j,i) < minVal){
					minVal = pts(j,i);
					ind.x = i;
					ind.y = j;
				}
			}
		}

		return ind;
	}

	void genPath(Node start, Eigen::MatrixXf mat_costs, std::vector<Node>& pts){
		Node curr = start;
		cv::Mat imgCp = this->img.clone();

		pts.clear();
		pts.push_back(curr);

		while(true){
			if(mat_costs(curr.y, curr.x) == 0){
				std::cout<<"Path Generated"<<std::endl;
				break;
			}

			int x_low = curr.x - 1;
			if(x_low < 0)
				x_low = 0;

			int x_high = curr.x + 2;
			if(x_high > imgCp.cols)
				x_high = imgCp.cols;

			int y_low = curr.y - 1;
			if(y_low < 0)
				y_low = 0;

			int y_high = curr.y + 2;
			if(y_high > imgCp.rows)
				y_high = imgCp.rows;

			Eigen::MatrixXf mat_window = mat_costs.block(y_low, x_low, y_high - y_low, x_high - x_low);

			Node ind_lowNeigh = this->minInd(mat_window);
			ind_lowNeigh.makeNode(ind_lowNeigh.x + x_low, ind_lowNeigh.y + y_low, 0);

			imgCp.at<uchar>(ind_lowNeigh.y, ind_lowNeigh.x) = 155;

			curr = ind_lowNeigh;
			pts.push_back(curr);
		}

	}

	void genCosts(Eigen::MatrixXf& mat_costs){
		// std::cout<<"q0"<<std::endl;
		// std::cout<<"X : "<<mat_costs.cols()<<", Y : "<<mat_costs.rows()<<std::endl;
		// std::cout<<"Goal : "<<goal.x<<','<<goal.y<<std::endl;
		mat_costs(goal.y, goal.x) = 0;
		// std::cout<<"q1"<<std::endl;
		std::vector<Node> list_open;
		// std::cout<<"q2"<<std::endl;
		list_open.push_back(this->goal);
		// std::cout<<"q3"<<std::endl;


		// std::cout<<"q"<<std::endl;
		while(list_open.size() != 0){
			// std::cout<<"qh"<<std::endl;
			Node curr = list_open[0];
			list_open.erase(list_open.begin());
			std::vector<Node> childNodes = this->genNeigh(curr);

			// std::cout<<"qj"<<std::endl;
			for(int j = 0;j < childNodes.size();j++){
				// std::cout<<"qt"<<std::endl;
				Node child = childNodes[j];
				// std::cout<<"qe"<<std::endl;

				if(img.at<uchar>(child.y,child.x) < 50){
					// std::cout<<"qw"<<std::endl;
					if(mat_costs(curr.y,curr.x) + child.g < mat_costs(child.y,child.x)){
						// std::cout<<"qi"<<std::endl;
						mat_costs(child.y,child.x) = mat_costs(curr.y,curr.x) + child.g;
						list_open.push_back(child);
						// std::cout<<"qo"<<std::endl;
					}
				}			
			}
		}
	}
};

#endif
					// std::cout<<"ga"<<std::endl;
					// std::cout<<"gb"<<std::endl;
					// std::cout<<"gc"<<std::endl;
					// std::cout<<"ge"<<std::endl;
					// std::cout<<"gf"<<std::endl;
					// std::cout<<"g1"<<std::endl;
					// 	std::cout<<"g2"<<std::endl;
					// 	std::cout<<"g3"<<std::endl;