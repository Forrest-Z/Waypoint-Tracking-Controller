#include <iostream>
#include "Data.h"
#include "func.h"
#include "IndicesDivider.h"


class TrajFromNodes{
std::vector<Node> wayPts;
float L = VehicleData::Length;

public:
	TrajFromNodes(std::vector<Node>& wayPts_) : wayPts(wayPts_){}

	Node executeAction(Node curr, float delta, float vel, float ti){
		Node next;

		float orien = curr.orien + vel*tan(delta)*ti/L;
		next.orien = (inRo(orien*180/PI)%360)*PI/180;

		if(delta*180/PI != 0){
			next.x = curr.x + L*(sin(next.orien) - sin(curr.orien))/tan(delta);
			next.y = curr.y + L*(cos(curr.orien) - cos(next.orien))/tan(delta);
		}
		else{
			next.x = curr.x + vel*cos(curr.orien)*ti;
			next.y = curr.y + vel*sin(curr.orien)*ti;
		}

		return next;
	}

	void genFrontCentredPoints(std::vector<Node>& pts){
		pts.clear();
		std::vector<Node> ptsFront;
		int numPts = TuningParams::PathExtensionNumPts;

		for(int i = 0;i < wayPts.size()-1;i++){
			Node curr = wayPts[i];
			Node next = wayPts[i + 1];

			for(int j = 0;j <= numPts;j++){
				Node newNode = executeAction(curr, next.delta, curr.velocity, AstarData::ActionLength*float(j)/numPts);
				newNode.x = newNode.x + VehicleData::Length*cos(newNode.orien);
				newNode.y = newNode.y + VehicleData::Length*sin(newNode.orien);
				ptsFront.push_back(newNode);
			}
		}

		// std::vector<int> indices;
		// IndicesDivider id(ptsFront.size(),180);
		// id.genIndices(indices);

		// for(int ind : indices)
		// 	pts.push_back(ptsFront[ind]);
		pts = ptsFront;

	}
};