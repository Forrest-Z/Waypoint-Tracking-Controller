#include <iostream>
#include "Data.h"
#include "func.h"


class LocalPlanner{
	std::vector<Node> globalPath;

public:
LocalPlanner(std::vector<Node>& globalPath_) :  globalPath(globalPath_){}
	

};
